﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;




namespace Assignment_53
{
    public partial class MainForm : Form
    {

        Random rand;

        int buttonCounter, textboxCounter= 1;

        Button currentButton;
        TextBox currentTextBox;

        TextBox previousTextBox;

        //StringBuilder textboxContent;

        private int formCounter;
        private int gap = 40;
        public MainForm()
        {
            InitializeComponent();
        }

        private void button_Click(object sender, EventArgs e)
        {

            this.BackColor = GetRandomColor();
            this.Location = new Point(int.Parse(rand.Next(1000).ToString()),
                int.Parse(rand.Next(500).ToString()));

            textBox.Text = string.Format("X: {0} Y: {1}", this.Location.X, this.Location.Y);
        }

        private void button_MouseClick(object sender, MouseEventArgs e)
        {

        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            rand = new Random();

            currentTextBox = textBox;
        }

        private Color GetRandomColor()
        {
            return Color.FromArgb(rand.Next(0, 255), rand.Next(0, 255), rand.Next(0, 255));
        }

        private void sizeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Size NewSize = new Size(0, 0);

            NewSize.Height = button.Size.Height * 2;

            NewSize.Width = button.Size.Width * 2;

            button.Size = NewSize;

            
        }

        private void backgroundColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            currentButton.BackColor = GetRandomColor();
        }

        private void duplicateFormToolStripMenuItem_Click(object sender, EventArgs e)
        {
            formCounter++;

            DuplicateForm newMDIChild = new DuplicateForm();
            newMDIChild.Text +=  " " + this.Text + " " + formCounter;
            //newMDIChild.MdiParent = this;

            newMDIChild.Show();
            
        }

        private void buttonToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddNewButton();

        }
        
        private void AddNewButton()
        {

            buttonCounter++;

              currentButton = new System.Windows.Forms.Button();

            //this is about newly added button location
              Point currentButtonLocation = button.Location;            

              currentButtonLocation.Y = buttonCounter * currentButton.Height + gap;
              currentButton.Location = currentButtonLocation;

              this.Controls.Add(currentButton);


              currentButton.Text = "Button" + this.buttonCounter.ToString();

            currentButton.ContextMenuStrip = this.buttonContextMenuStrip;

            currentButton.Click += new System.EventHandler(button_Click);
            currentButton.MouseHover += new System.EventHandler(button_MouseHover);   

        }

       
        private void textBoxToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddNewTextBox();
        }

        public void AddNewTextBox()
        {
            previousTextBox = textBox;

            textboxCounter++;


             currentTextBox = new System.Windows.Forms.TextBox();
             this.Controls.Add(currentTextBox);

             //this is about newly added textbox location
             Point currentTextBoxLocation = textBox.Location;

             
             currentTextBoxLocation.Y = textboxCounter * currentTextBox.Height + gap;

             currentTextBox.Location = currentTextBoxLocation;

             //textboxContent.Append(textBox.Text);

             currentTextBox.Text = previousTextBox.Text + " " + textBox.Text;
            
        }


        private void button_MouseHover(object sender, EventArgs e)
        {
            currentButton = (Button) sender;
        }
    }
}

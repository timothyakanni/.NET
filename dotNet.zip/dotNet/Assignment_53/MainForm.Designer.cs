﻿namespace Assignment_53
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.textBox = new System.Windows.Forms.TextBox();
            this.button = new System.Windows.Forms.Button();
            this.buttonContextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.sizeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.backgroundColorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mainFormContextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.duplicateFormToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addControlToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.textBoxToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonContextMenuStrip.SuspendLayout();
            this.mainFormContextMenuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBox
            // 
            this.textBox.Location = new System.Drawing.Point(-1, 0);
            this.textBox.Multiline = true;
            this.textBox.Name = "textBox";
            this.textBox.Size = new System.Drawing.Size(232, 39);
            this.textBox.TabIndex = 0;
            // 
            // button
            // 
            this.button.ContextMenuStrip = this.buttonContextMenuStrip;
            this.button.Location = new System.Drawing.Point(253, 16);
            this.button.Name = "button";
            this.button.Size = new System.Drawing.Size(75, 23);
            this.button.TabIndex = 1;
            this.button.Text = "Button";
            this.button.UseVisualStyleBackColor = true;
            this.button.Click += new System.EventHandler(this.button_Click);
            this.button.MouseClick += new System.Windows.Forms.MouseEventHandler(this.button_MouseClick);
            this.button.MouseHover += new System.EventHandler(this.button_MouseHover);
            // 
            // buttonContextMenuStrip
            // 
            this.buttonContextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sizeToolStripMenuItem,
            this.backgroundColorToolStripMenuItem});
            this.buttonContextMenuStrip.Name = "contextMenuStrip";
            this.buttonContextMenuStrip.Size = new System.Drawing.Size(168, 48);
            // 
            // sizeToolStripMenuItem
            // 
            this.sizeToolStripMenuItem.Name = "sizeToolStripMenuItem";
            this.sizeToolStripMenuItem.Size = new System.Drawing.Size(167, 22);
            this.sizeToolStripMenuItem.Text = "size";
            this.sizeToolStripMenuItem.Click += new System.EventHandler(this.sizeToolStripMenuItem_Click);
            // 
            // backgroundColorToolStripMenuItem
            // 
            this.backgroundColorToolStripMenuItem.Name = "backgroundColorToolStripMenuItem";
            this.backgroundColorToolStripMenuItem.Size = new System.Drawing.Size(167, 22);
            this.backgroundColorToolStripMenuItem.Text = "backgroundColor";
            this.backgroundColorToolStripMenuItem.Click += new System.EventHandler(this.backgroundColorToolStripMenuItem_Click);
            // 
            // mainFormContextMenuStrip
            // 
            this.mainFormContextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.duplicateFormToolStripMenuItem,
            this.addControlToolStripMenuItem});
            this.mainFormContextMenuStrip.Name = "mainFormContextMenuStrip";
            this.mainFormContextMenuStrip.Size = new System.Drawing.Size(156, 48);
            // 
            // duplicateFormToolStripMenuItem
            // 
            this.duplicateFormToolStripMenuItem.Name = "duplicateFormToolStripMenuItem";
            this.duplicateFormToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.duplicateFormToolStripMenuItem.Text = "Duplicate Form";
            this.duplicateFormToolStripMenuItem.Click += new System.EventHandler(this.duplicateFormToolStripMenuItem_Click);
            // 
            // addControlToolStripMenuItem
            // 
            this.addControlToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buttonToolStripMenuItem,
            this.textBoxToolStripMenuItem});
            this.addControlToolStripMenuItem.Name = "addControlToolStripMenuItem";
            this.addControlToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.addControlToolStripMenuItem.Text = "Add Control";
            // 
            // buttonToolStripMenuItem
            // 
            this.buttonToolStripMenuItem.Name = "buttonToolStripMenuItem";
            this.buttonToolStripMenuItem.Size = new System.Drawing.Size(115, 22);
            this.buttonToolStripMenuItem.Text = "Button";
            this.buttonToolStripMenuItem.Click += new System.EventHandler(this.buttonToolStripMenuItem_Click);
            // 
            // textBoxToolStripMenuItem
            // 
            this.textBoxToolStripMenuItem.Name = "textBoxToolStripMenuItem";
            this.textBoxToolStripMenuItem.Size = new System.Drawing.Size(115, 22);
            this.textBoxToolStripMenuItem.Text = "TextBox";
            this.textBoxToolStripMenuItem.Click += new System.EventHandler(this.textBoxToolStripMenuItem_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(340, 375);
            this.ContextMenuStrip = this.mainFormContextMenuStrip;
            this.Controls.Add(this.button);
            this.Controls.Add(this.textBox);
            this.Name = "MainForm";
            this.Text = "Assgn_52";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.buttonContextMenuStrip.ResumeLayout(false);
            this.mainFormContextMenuStrip.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox;
        private System.Windows.Forms.Button button;
        private System.Windows.Forms.ContextMenuStrip buttonContextMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem sizeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem backgroundColorToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip mainFormContextMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem duplicateFormToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addControlToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem textBoxToolStripMenuItem;
    }
}


﻿namespace Retake_Exam_Q1
{
    partial class Add_Search_Fitness_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.addFitnessProgramToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.searchFitnessProgramToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addFitnessProgramToolStripMenuItem,
            this.searchFitnessProgramToolStripMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(377, 24);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "menuStrip";
            // 
            // addFitnessProgramToolStripMenuItem
            // 
            this.addFitnessProgramToolStripMenuItem.Name = "addFitnessProgramToolStripMenuItem";
            this.addFitnessProgramToolStripMenuItem.Size = new System.Drawing.Size(129, 20);
            this.addFitnessProgramToolStripMenuItem.Text = "Add Fitness Program";
            this.addFitnessProgramToolStripMenuItem.Click += new System.EventHandler(this.addFitnessProgramToolStripMenuItem_Click);
            // 
            // searchFitnessProgramToolStripMenuItem
            // 
            this.searchFitnessProgramToolStripMenuItem.Name = "searchFitnessProgramToolStripMenuItem";
            this.searchFitnessProgramToolStripMenuItem.Size = new System.Drawing.Size(142, 20);
            this.searchFitnessProgramToolStripMenuItem.Text = "Search Fitness Program";
            this.searchFitnessProgramToolStripMenuItem.Click += new System.EventHandler(this.searchFitnessProgramToolStripMenuItem_Click);
            // 
            // Add_Search_Fitness_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(377, 374);
            this.Controls.Add(this.menuStrip);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip;
            this.Name = "Add_Search_Fitness_Form";
            this.Text = "Add_Search_Fitness_Form";
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStripMenuItem addFitnessProgramToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem searchFitnessProgramToolStripMenuItem;
    }
}


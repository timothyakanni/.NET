﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Retake_Exam_Q1
{
    class FitnessProgram
    {
        private string name;
        private string duration;
        private string day_time_place;

        List<String> daytime_place = new List<string>();


        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public string Duration
        {
            get { return duration; }
            set { duration = value; }
        }

        public string Day_Time_Value
        {
            get { return day_time_place; }
            set { day_time_place = value; }
        }
                
        public FitnessProgram(string name, string duration, string day_time_place)
        {
            this.name = name;
            this.duration = duration;
            this.day_time_place = day_time_place;
        }

        public FitnessProgram()
        {
            this.name = "not_known";
            this.duration = "not_known";
            this.day_time_place = "not_known";
        }

        public List<String> AddDayTimePlace(string day, string time, string place){

            string item = day + " " + time + " " + place;
            daytime_place.Add(item);
              
            return daytime_place;
        }
        
        public void AddProgram(string name, string duration, string day_time_place){

            string connectionString;

            connectionString = "datasource=mysql.cc.puv.fi;database=e1100617_examples;username=e1100617;password=v5ZeGaHttjxs";

            MySqlConnection conn = new MySqlConnection(connectionString);
            MySqlCommand insertCommand = new MySqlCommand("insert into e1100617_examples.FitnessProgram (Name, Duration, Day_Time_Place) values('" +
                name + "','" + duration + "','" + day_time_place + "')", conn);

            try
            {

                conn.Open();
                MySqlDataReader dataReader = insertCommand.ExecuteReader();
                MessageBox.Show("DATA SUCCESFULLY SAVED!!!");
                return;

            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
        }


       
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Retake_Exam_Q1
{
    public partial class Add_Search_Fitness_Form : Form
    {
        public Add_Search_Fitness_Form()
        {
            InitializeComponent();
        }

        private void addFitnessProgramToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Add_Fitness_Program afp = new Add_Fitness_Program();
            afp.MdiParent = this;
            afp.Show();  
        }

        private void searchFitnessProgramToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Search_Fitness_Program sfp = new Search_Fitness_Program();
            sfp.MdiParent = this;
            sfp.Show(); 

        }
    }
}

﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Retake_Exam_Q1
{
    public partial class Add_Fitness_Program : Form
    {

        FitnessProgram fp = new FitnessProgram();
        public Add_Fitness_Program()
        {
            InitializeComponent();
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            string day_time_place = dayTextBox.Text + " " + timeTextBox.Text + " " + placeTextBox.Text;
            fp.AddProgram(nameTextBox.Text, durationTextBox.Text, day_time_place);           
        }

        private void dayCollectionButton_Click(object sender, EventArgs e)
        {
            fp.AddDayTimePlace(dayTextBox.Text, timeTextBox.Text, placeTextBox.Text);
        }

        
    }
}

﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Retake_Exam_Q1
{
    public partial class Search_Fitness_Program : Form
    {
        public Search_Fitness_Program()
        {
            InitializeComponent();
        }

        private void searchButton_Click(object sender, EventArgs e)
        {

            string connectionString = "datasource=mysql.cc.puv.fi;database=e1100617_examples;username=e1100617;password=v5ZeGaHttjxs";

            //Here we initialize the mySqlConn object.
            MySqlConnection conn = new MySqlConnection(connectionString);

            //Here we initialize mySqlDataAdapter
            MySqlCommand command = new MySqlCommand("Select Name, Duration, Day_Time_Place from e1100617_examples.FitnessProgram where Name ='" + searchNameTextBox.Text + "' ", conn);

            try
            {
                MySqlDataAdapter sda = new MySqlDataAdapter();
                sda.SelectCommand = command;

                DataTable dbDataset = new DataTable();
                sda.Fill(dbDataset);

                BindingSource bSource = new BindingSource();

                bSource.DataSource = dbDataset;
                dataGridView1.DataSource = bSource;

                sda.Update(dbDataset);

            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
    }
}

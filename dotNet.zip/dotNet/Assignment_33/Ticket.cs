﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace Assignment_33
{
    //Beginning of Ticket class
    class Ticket
    {
        private string ticketID;

        private string passengerID;

        private Flight flight;

        private double price;

        public readonly double extraTax;



        private ArrayList ticketObjs;


        public Ticket()
        {
            ticketObjs = new ArrayList();
        }

        public Ticket this[int index]
        {
            set
            {
                ticketObjs.Add(value);
            }

            get
            {
                return (Ticket)ticketObjs[index];
            }
        }
        public string TicketID
        {
            get { return ticketID; }
            set { ticketID = value; }

        }

        public string PassengerID
        {
            get { return passengerID; }
            set { passengerID = value; }

        }
        public double Price
        {
            get { return price; }
            set { price = value; }

        }

        public Ticket(string ticketID, string passengerID, Flight flight, double price)
        {

            this.ticketID = ticketID;

            this.passengerID = passengerID;

            this.price = price + extraTax;

            this.flight = flight;

            try
            {

                if (flight.date.DayOfWeek == DayOfWeek.Saturday || flight.date.DayOfWeek == DayOfWeek.Sunday)

                    this.extraTax = 0.07;

                else

                    this.extraTax = 0.05;
            }
            catch (FormatException e)
            {

                Console.WriteLine(e.Message);

            }

        }

        //Here we define ToString() method for Ticket
        public override string ToString()
        {
            return ticketID + " " + passengerID + " " + price + flight.ToString();
        }

        //Here is GetPrice method
        public double GetPrice(string ticketID)
        {
            //foreach (Ticket t in ticketObjs) { 

            if (this.ticketID.Equals(ticketID))

                return (this.price += this.extraTax);

            //}
                return 0;

        }

        //Here we define method which recieves array of passengers
        //returns the information of the flight and passengers to which the ticket belong to as well as the ticket price.
        public string GetPassInfo(ArrayList passengerList)
        {

            string info = " ";
            foreach (Passenger p in passengerList)
            {
                foreach (Ticket t in p.Tickets)
                {
                    if (t.PassengerID.Equals(this.passengerID))

                        info = p.ToString()  + "--->" + this.price + "\n";
                }


            }


            return info;
        }


    }//End of Ticket class
}

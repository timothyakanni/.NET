﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assignment_33
{

    //Beginning of Flight class
    class Flight
    {
        private int fid;

        private string origin;

        private string dest;

        public DateTime date = DateTime.Parse("10.2.2010 12:30");



        private ArrayList flightObjs;

        public Flight()
        {
            flightObjs = new ArrayList();
        }

        //Here we define indexer for the class
        public Flight this[int index]
        {
            set
            {
                flightObjs.Add(value);
            }

            get
            {
                return (Flight)flightObjs[index];
            }
        }
        
        public int Fid
        {
            get { return fid; }
            set { fid = value; }
        }

        public string Origin
        {
            get { return origin; }
            set { origin = value; }
        }

        public string Dest
        {
            get { return dest; }
            set { dest = value; }
        }
       

        public Flight(int fid, string origin, string dest, DateTime date)
        {
            this.fid = fid;

            this.origin = origin;

            this.dest = dest;

            this.date = date;

        }

        public override string ToString()
        {
            return fid + " " + origin + " " + dest + " " + " " + date;
        }

        //Here we define get Get flight info method
        public string GetFlightInfo(int fid)
        {


            foreach (Flight f in flightObjs)
            {

                if (f.fid == fid)

                    return f.ToString();

            }
            return "Incorrect Flight ID";
        }



       

    }//End of Flight class
}

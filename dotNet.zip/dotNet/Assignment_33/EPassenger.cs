﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assignment_33
{
    //Beginning of Economy Passenger class
    class EPassenger : Passenger
    {

        protected int lugWeight;

        public EPassenger(string pid, string lastName, string firstName, int phoneNumber, ArrayList Tickets, int lugWeight)
            : base(pid, lastName, firstName, phoneNumber, Tickets)
        {
            this.lugWeight = lugWeight;

        }


        //Here we override GetInfo virtual method in Passenegr
        public override string GetInfo(string pid)
        {
            if (this.pid.Equals(pid))
            {

                string info = "Economy Passenger: " + pid + " " + lastName + " " + firstName + " " + phoneNumber + " " + lugWeight;

                foreach (Ticket t in Tickets)
                    if (t.PassengerID.Equals(pid))
                    {

                        info += t.ToString();
                    }

                return info;
            }

            else
                return "ID does not exist in economy passenger";

        }

        public override bool PassengerGetInfoFound(string pid)
        {
            if (this.pid.Equals(pid))
                return true;

            return false;
        }

    }//End of Passenger class

}

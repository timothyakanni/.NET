﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assignment_33
{
    //Beginning of First Class Passenger class
    class FCPassenger : EPassenger
    {
        private double bonus;

        private string mealMenu;

        public FCPassenger(string pid, string lastName, string firstName, int phoneNumber, ArrayList Tickets, int lugWeight, double bonus, string mealMenu)
            : base(pid, lastName, firstName, phoneNumber, Tickets, lugWeight)
        {
            this.bonus = bonus;

            this.mealMenu = mealMenu;

        }

        //Here is read only property for bonus
        public double Bonus
        {
            get { return 0.02; }
            
        }


        //Here we override GetInfo virtual method in Passenegr
        public override string GetInfo(string pid)
        {
            if (this.pid.Equals(pid))
            {

                string info = "First Class Passenger: " + pid + " " + lastName + " " + firstName + " " + phoneNumber;

                foreach (Ticket t in Tickets)
                    if (t.PassengerID.Equals(pid))
                    {

                        info += t.ToString();
                    }

                return info;
            }

            else
                return "ID does not exist in First Class passenger";

        }

        public override bool PassengerGetInfoFound(string pid)
        {
            if (this.pid.Equals(pid))
                return true;

            return false;
        }


    }//End of First Class Passenger class
}

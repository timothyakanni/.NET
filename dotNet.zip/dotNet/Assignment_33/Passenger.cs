﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace Assignment_33
{
    //Beginning of Passenger class
    class Passenger
    {
        protected string pid;

        protected string lastName;

        protected string firstName;

        protected int phoneNumber;

        public ArrayList Tickets;

        

       /* public Ticket Tickets
        {
            get { return tickets; }
            set { tickets = value; }
        }*/


        public string Pid
        {
            get { return pid; }
            set { pid = value; }
        }
        //this is constructor
        public Passenger(string pid, string lastName, string firstName, int phoneNumber, ArrayList Tickets)
        {
            this.pid = pid;

            this.lastName = lastName;

            this.firstName = firstName;

            this.phoneNumber = phoneNumber;

            this.Tickets = Tickets;

        }

        public override string ToString()
        {
            return pid + " " + lastName + " " + firstName + " " + phoneNumber;
        }

        //Here is GetInfo() virtual method

        public virtual string GetInfo(string pid)
        {

            if (this.pid.Equals(pid))
            {

                string info = pid + " " + lastName + " " + firstName + " " + phoneNumber + "\n";

                foreach (Ticket t in Tickets)
                    if (t.PassengerID.Equals(pid))
                    {

                        info += t.ToString();
                    }

                return info;
            }

            else
                return "ID does not exist in passenger";

        }
        public virtual bool PassengerGetInfoFound(string pid)
        {
            if (this.pid.Equals(pid))
                return true;

            return false;
        }

    }//End of Passenger class
}

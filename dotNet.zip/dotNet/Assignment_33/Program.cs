﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;



namespace Assignment_33
{     
   

    class Program
    {
        static void Main(string[] args)
        {

            Flight flights = new Flight();

            flights[0] = new Flight(100, "FI", "NS", new DateTime(2015, 3, 12, 10, 15, 0, 0));
            flights[1] = new Flight(200, "CA", "NY", new DateTime(2015, 5, 12, 10, 15, 0, 0));
            flights[2] = new Flight(300, "FI", "SW", new DateTime(2015, 7, 12, 10, 15, 0, 0));
            flights[3] = new Flight(400, "GER", "NS", new DateTime(2015, 8, 12, 10, 15, 0, 0));
            flights[4] = new Flight(500, "FI", "SA", new DateTime(2015, 10, 12, 10, 15, 0, 0));

            ArrayList tickets = new ArrayList();

            tickets.Add(new Ticket("T100", "P100", flights[0], 20.50));
            tickets.Add(new Ticket("T200", "P200", flights[1], 5.50));
            tickets.Add( new Ticket("T300", "P300", flights[2], 10.50));
            tickets.Add(new Ticket("T400", "P400", flights[3], 25.50));
            tickets.Add(new Ticket("T500", "P500", flights[4], 25.50));

            ArrayList passengers = new ArrayList();

            passengers.Add(new Passenger("P100", "Julis", "Baba", 0402345, tickets));
            passengers.Add(new Passenger("P200", "Laura", "Stone", 0502345, tickets));
            passengers.Add(new Passenger("P300", "West", "Putty", 0602345, tickets));
            passengers.Add(new Passenger("P400", "Steve", "Job", 0702345, tickets));
            passengers.Add(new Passenger("P500", "Lincol", "Sand", 0802345, tickets));

            ArrayList epassengers = new ArrayList();

            epassengers.Add(new EPassenger("EP100", "Julis", "Baba", 0402345, tickets, 50));
            epassengers.Add(new EPassenger("EP200", "Laura", "Stone", 0502345, tickets, 75));
            epassengers.Add(new EPassenger("EP300", "West", "Putty", 0602345, tickets, 100));
            epassengers.Add(new EPassenger("EP400", "Steve", "Job", 0702345, tickets, 80));
            epassengers.Add(new EPassenger("EP500", "Lincol", "Sand", 0802345, tickets, 65));

            ArrayList fcpassengers = new ArrayList();

            fcpassengers.Add(new FCPassenger("FCP100", "Julis", "Baba", 0402345, tickets, 50, 10.89, "Pasta and Wine"));
            fcpassengers.Add(new FCPassenger("FCP200", "Laura", "Stone", 0502345, tickets, 75, 5.75, "Bread and Butter" ));
            fcpassengers.Add(new FCPassenger("FCP300", "West", "Putty", 0602345, tickets, 100, 2.75, "Rice and Beer"));
            fcpassengers.Add(new FCPassenger("FCP400", "Steve", "Job", 0702345, tickets, 80, 1.75, "Cheese Burger"));
            fcpassengers.Add(new FCPassenger("FCP500", "Lincol", "Sand", 0802345, tickets, 65, 4.75, "Vegetables and Fruits"));


            Console.WriteLine(" ");
            Console.Write("---Here We test Get Flight Info method in Flight----");

            Console.WriteLine(" ");
            Console.Write("Type Flight ID: ");
            int FId = Int32.Parse(Console.ReadLine());
            Console.WriteLine(FId);
            Console.Write(((Flight)flights).GetFlightInfo(FId));                
          
            
            Console.WriteLine(" ");
            Console.Write("---Here we test Get Ticket Price method in Ticket----");

            Console.WriteLine(" ");
            Console.Write("Type Ticket ID: ");
            string TId = Console.ReadLine();
            Console.WriteLine(TId);   
            for(int i =0; i < tickets.Count; i++)
            Console.Write(((Ticket)tickets[i]).GetPrice(TId));

            Console.WriteLine(" ");
            Console.Write("---Here we test Get Passenger Info method in Ticket----");

            Console.WriteLine(" ");            
                Console.Write(((Ticket)tickets[3]).GetPassInfo(passengers));

            Console.WriteLine(" ");
            Console.Write("---Here we test Get Info virtual method in Passenger----");

            Console.WriteLine(" ");
            Console.Write("Type Passenger ID: ");
            string PId = Console.ReadLine();
            Console.WriteLine(PId);
            for (int i = 0; i < passengers.Count; i++ )
                if (((Passenger)passengers[i]).PassengerGetInfoFound(PId))
                Console.Write(((Passenger)passengers[i]).GetInfo(PId));

            Console.WriteLine(" ");
            Console.Write("---Here we test Get Info method in EPassenger----");

            Console.WriteLine(" ");
            Console.Write("Type EPassenger ID: ");
            string ePId = Console.ReadLine();
            Console.WriteLine(ePId);
            for (int i = 0; i < epassengers.Count; i++ )
                if (((EPassenger)epassengers[i]).PassengerGetInfoFound(PId))
                Console.Write(((EPassenger)epassengers[0]).GetInfo(ePId));

            Console.WriteLine(" ");
            Console.Write("---Here we test Get Info method in FCPassenger----");

            Console.WriteLine(" ");
            Console.Write("Type FCPassenger ID: ");
            string fcPId = Console.ReadLine();
            Console.WriteLine(ePId);
            for (int i = 0; i < fcpassengers.Count; i++)
                if (((FCPassenger)fcpassengers[i]).PassengerGetInfoFound(PId))
                Console.Write(((FCPassenger)fcpassengers[i]).GetInfo(fcPId));


          
        }
    }
}

﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace Assignment_32
{
   
    //Here we define delegate for processing flight
    public delegate void ProcessFlightDelegate(Flight flight);   


    class Program
    {
        static void DisplayFlightInfo(Flight flight)
        {

            Console.WriteLine(flight.ToString());

        }       
        static void Main(string[] args)
        {


            Flight flight = new Flight();

            flight[0] = new Flight(100, "FI", "NS", 50.50, new DateTime(2015, 3, 12, 10, 15, 0, 0));
            flight[1] = new Flight(200, "CA", "NY", 30.50, new DateTime(2015, 5, 12, 10, 15, 0, 0));
            flight[2] = new Flight(300, "FI", "SW", 20.50, new DateTime(2015, 7, 12, 10, 15, 0, 0));

            Console.Write("---Here We print flight Info Flight ID----");

            Console.WriteLine(" ");
            Console.Write("Type Flight ID: ");
            int fId = Int16.Parse(Console.ReadLine());
            Console.WriteLine(fId);

            Console.Write(flight.GetFlightInfo(fId));
            Console.WriteLine(" ");

            Console.WriteLine("Flights with prices lower than 50 euros:");
            //Here we call ProcessCheapFlightss() method and pass a delegate instance to it

            double price;

            Console.Write("Please enter a price: ");

            price = Int16.Parse(Console.ReadLine());

            ProcessFlightDelegate pfd = new ProcessFlightDelegate(DisplayFlightInfo);

            flight.ProcessCheapFlight(pfd, price);


          

        }
    }
}

﻿namespace Assignment_64
{
    partial class Product_Info_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.comboBox = new System.Windows.Forms.ComboBox();
            this.category = new System.Windows.Forms.Label();
            this.product_id = new System.Windows.Forms.Label();
            this.product_name = new System.Windows.Forms.Label();
            this.product_unit_price = new System.Windows.Forms.Label();
            this.amount = new System.Windows.Forms.Label();
            this.productIdTextBox = new System.Windows.Forms.TextBox();
            this.productNameTextBox = new System.Windows.Forms.TextBox();
            this.unitPriceTextBox = new System.Windows.Forms.TextBox();
            this.amountTextBox = new System.Windows.Forms.TextBox();
            this.productButton = new System.Windows.Forms.Button();
            this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.SuspendLayout();
            // 
            // comboBox
            // 
            this.comboBox.FormattingEnabled = true;
            this.comboBox.Location = new System.Drawing.Point(134, 38);
            this.comboBox.Name = "comboBox";
            this.comboBox.Size = new System.Drawing.Size(140, 21);
            this.comboBox.TabIndex = 0;
            // 
            // category
            // 
            this.category.AutoSize = true;
            this.category.Location = new System.Drawing.Point(33, 46);
            this.category.Name = "category";
            this.category.Size = new System.Drawing.Size(49, 13);
            this.category.TabIndex = 1;
            this.category.Text = "Category";
            // 
            // product_id
            // 
            this.product_id.AutoSize = true;
            this.product_id.Location = new System.Drawing.Point(33, 95);
            this.product_id.Name = "product_id";
            this.product_id.Size = new System.Drawing.Size(58, 13);
            this.product_id.TabIndex = 2;
            this.product_id.Text = "Product ID";
            // 
            // product_name
            // 
            this.product_name.AutoSize = true;
            this.product_name.Location = new System.Drawing.Point(33, 135);
            this.product_name.Name = "product_name";
            this.product_name.Size = new System.Drawing.Size(35, 13);
            this.product_name.TabIndex = 3;
            this.product_name.Text = "Name";
            // 
            // product_unit_price
            // 
            this.product_unit_price.AutoSize = true;
            this.product_unit_price.Location = new System.Drawing.Point(33, 181);
            this.product_unit_price.Name = "product_unit_price";
            this.product_unit_price.Size = new System.Drawing.Size(53, 13);
            this.product_unit_price.TabIndex = 4;
            this.product_unit_price.Text = "Unit Price";
            // 
            // amount
            // 
            this.amount.AutoSize = true;
            this.amount.Location = new System.Drawing.Point(33, 229);
            this.amount.Name = "amount";
            this.amount.Size = new System.Drawing.Size(43, 13);
            this.amount.TabIndex = 5;
            this.amount.Text = "Amount";
            // 
            // productIdTextBox
            // 
            this.productIdTextBox.Location = new System.Drawing.Point(134, 88);
            this.productIdTextBox.Name = "productIdTextBox";
            this.productIdTextBox.Size = new System.Drawing.Size(140, 20);
            this.productIdTextBox.TabIndex = 6;
            // 
            // productNameTextBox
            // 
            this.productNameTextBox.Location = new System.Drawing.Point(134, 132);
            this.productNameTextBox.Name = "productNameTextBox";
            this.productNameTextBox.Size = new System.Drawing.Size(140, 20);
            this.productNameTextBox.TabIndex = 7;
            // 
            // unitPriceTextBox
            // 
            this.unitPriceTextBox.Location = new System.Drawing.Point(134, 178);
            this.unitPriceTextBox.Name = "unitPriceTextBox";
            this.unitPriceTextBox.Size = new System.Drawing.Size(140, 20);
            this.unitPriceTextBox.TabIndex = 8;
            // 
            // amountTextBox
            // 
            this.amountTextBox.Location = new System.Drawing.Point(134, 222);
            this.amountTextBox.Name = "amountTextBox";
            this.amountTextBox.Size = new System.Drawing.Size(140, 20);
            this.amountTextBox.TabIndex = 9;
            // 
            // productButton
            // 
            this.productButton.Location = new System.Drawing.Point(134, 273);
            this.productButton.Name = "productButton";
            this.productButton.Size = new System.Drawing.Size(75, 23);
            this.productButton.TabIndex = 10;
            this.productButton.Text = "Submit";
            this.productButton.UseVisualStyleBackColor = true;
            this.productButton.Click += new System.EventHandler(this.productButton_Click);
            // 
            // Product_Info_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(341, 352);
            this.Controls.Add(this.productButton);
            this.Controls.Add(this.amountTextBox);
            this.Controls.Add(this.unitPriceTextBox);
            this.Controls.Add(this.productNameTextBox);
            this.Controls.Add(this.productIdTextBox);
            this.Controls.Add(this.amount);
            this.Controls.Add(this.product_unit_price);
            this.Controls.Add(this.product_name);
            this.Controls.Add(this.product_id);
            this.Controls.Add(this.category);
            this.Controls.Add(this.comboBox);
            this.Name = "Product_Info_Form";
            this.Text = "Product_Info_Form";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBox;
        private System.Windows.Forms.Label category;
        private System.Windows.Forms.Label product_id;
        private System.Windows.Forms.Label product_name;
        private System.Windows.Forms.Label product_unit_price;
        private System.Windows.Forms.Label amount;
        private System.Windows.Forms.TextBox productIdTextBox;
        private System.Windows.Forms.TextBox productNameTextBox;
        private System.Windows.Forms.TextBox unitPriceTextBox;
        private System.Windows.Forms.TextBox amountTextBox;
        private System.Windows.Forms.Button productButton;
        private System.Windows.Forms.SaveFileDialog saveFileDialog;
    }
}
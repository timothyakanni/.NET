﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace Assignment_64
{
    public partial class Product_Info_Form : Form
    {

        string productFilePathName;
        public Product_Info_Form()
        {
            InitializeComponent();
        }

        private void productButton_Click(object sender, EventArgs e)
        {
            if (comboBox.Text.Length != 0 && productIdTextBox.Text.Length != 0 && productNameTextBox.Text.Length != 0
                && unitPriceTextBox.Text.Length != 0 && amountTextBox.Text.Length != 0)
            {



                saveFileDialog.InitialDirectory = productFilePathName;

                saveFileDialog.Filter = "Text Files (*.txt)|*.txt|XML Files (*.xml)|*.xml|All files (*.*)|*.*";

                if (saveFileDialog.ShowDialog().Equals(DialogResult.OK))
                {

                    XmlSerializer sr = new XmlSerializer(sender.GetType());

                    StreamWriter writer = new StreamWriter(productFilePathName);
                    sr.Serialize(writer, sender);

                    writer.Close();

                    //UTF8Encoding coding;
                    //productFilePathName = saveFileDialog.FileName;
                    ////toolStripFilePathTextBox.Text = filePathName;

                    //StreamWriter sw = File.WriteAllText(productFilePathName, comboBox.Text + productIdTextBox.Text +
                    // productNameTextBox.Text + unitPriceTextBox.Text + amountTextBox.Text, Encoding.UTF-8);
                    ////sw.WriteAllText(mainTextBox.Text);
                    //sw.Close();


                }
            }
            else
                MessageBox.Show("Fill the missing part");


        }

       
       
            

        
    }
}

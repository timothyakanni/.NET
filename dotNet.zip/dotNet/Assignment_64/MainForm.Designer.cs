﻿namespace Assignment_64
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.enterProductInfoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.searchAndDispalyProductToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.enterProductInfoToolStripMenuItem,
            this.searchAndDispalyProductToolStripMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(507, 24);
            this.menuStrip.TabIndex = 1;
            this.menuStrip.Text = "menuStrip";
            // 
            // enterProductInfoToolStripMenuItem
            // 
            this.enterProductInfoToolStripMenuItem.Name = "enterProductInfoToolStripMenuItem";
            this.enterProductInfoToolStripMenuItem.Size = new System.Drawing.Size(157, 20);
            this.enterProductInfoToolStripMenuItem.Text = "Enter Product Information";
            this.enterProductInfoToolStripMenuItem.Click += new System.EventHandler(this.enterProductInfoToolStripMenuItem_Click);
            // 
            // searchAndDispalyProductToolStripMenuItem
            // 
            this.searchAndDispalyProductToolStripMenuItem.Name = "searchAndDispalyProductToolStripMenuItem";
            this.searchAndDispalyProductToolStripMenuItem.Size = new System.Drawing.Size(163, 20);
            this.searchAndDispalyProductToolStripMenuItem.Text = "Search and Dispaly Product";
            this.searchAndDispalyProductToolStripMenuItem.Click += new System.EventHandler(this.searchAndDispalyProductToolStripMenuItem_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(507, 499);
            this.Controls.Add(this.menuStrip);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip;
            this.Name = "MainForm";
            this.Text = "Assignment_64";
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStripMenuItem enterProductInfoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem searchAndDispalyProductToolStripMenuItem;
    }
}


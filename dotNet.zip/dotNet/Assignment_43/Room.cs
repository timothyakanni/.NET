﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Soap;

namespace Assignment_43
{

    [Serializable]
    class Room
    {

        protected string roomNum;

        protected string area;

        protected string type;

        protected double price;

        protected string descript;

        string rfilePath = @"U:\Temp\rooms.xml";

        public Room(string roomNum, string area, string type, double price, string descript)
        {
            this.roomNum = roomNum;
            this.area = area;
            this.type = type;
            this.price = price;
            this.descript = descript;

        }

        public Room()
        {
            this.roomNum = "";
            this.area = "";
            this.type = "";
            this.price = 0.00;
            this.descript = "";

        }

        public string RoomNum
        {
            get { return roomNum; }
            set { roomNum = value; }
        }
        public string Area
        {
            get { return area; }
            set { area = value; }
        }
        public string Type
        {
            get { return type; }
            set { type = value; }
        }
        public double Price
        {
            get { return price; }
            set { price = value; }
        }
        public string Descript
        {
            get { return descript; }
            set { descript = value; }
        }

        public override string ToString()
        {
            return " Room Number: " + roomNum + " Area: " + area + " Type: " + type +
                " Price: " + price + " Description: " + descript + "\n";
        }

        public string FindRoom(string roomNum)
        {

            if (this.roomNum.Equals(roomNum))
                return this.ToString();

            return "";
        }


        public void serializeAndDeserialzeRoom(List<Room> rooms)
        {
            //Here we create a FileStream to hold the serialized room
            FileStream fileStream = new FileStream(rfilePath, FileMode.OpenOrCreate);

            //Here we use the CLR's binary formatting support
            SoapFormatter soapFormatter = new SoapFormatter();

            //Here we serialize the objects

            for (int i = 0; i < rooms.Count; i++)
                soapFormatter.Serialize(fileStream, rooms[i]);


            fileStream.Flush();
            fileStream.Close();



            //Here we retrieve the serialized for room objects
            fileStream = new FileStream(rfilePath, FileMode.Open);

            object roomObj = null;
            string roomNumber = "R200";
            string result;

            for (; ; )
            {
                try
                {

                    roomObj = soapFormatter.Deserialize(fileStream);



                    //Here we check whether obj is of type Employee
                    //or not and if it is, we type cast it to Employee
                    //and call the GetEmployee() method.
                    if (roomObj is Room)
                    {
                        result = ((Room)roomObj).FindRoom(roomNumber);

                        if (!string.IsNullOrEmpty(result))
                            Console.WriteLine("Information of Room with room number: " + roomNumber + ":\n" +
                                Environment.NewLine + result);

                    }


                }
                catch (EndOfStreamException e)
                {
                    Console.WriteLine("No object left!" + e.Message);
                }
                catch (SerializationException)
                {
                    //Console.WriteLine(e.Message);
                    break;
                }

                catch (System.Xml.XmlException)
                {
                    //Console.WriteLine(e.Message);
                    break;
                }

            }

        }


    }
}




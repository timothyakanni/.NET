﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization.Formatters.Soap;

namespace Assignment_43
{
    [Serializable]
    class Customer
    {

        protected string customerName;

        protected string customerAddress;

        protected string customerRoomNum;

        protected int stayNights;

        public DateTime arrivalDate = DateTime.Parse("08.2.2010 12:30");

        string cfilePath = @"U:\Temp\customers.xml";
        

        public Customer(string customerName, string customerAddress, string customerRoomNum,
            int stayNights)
        {
            this.customerName = customerName;
            this.customerAddress = customerAddress;
            this.customerRoomNum = customerRoomNum;
            this.stayNights = stayNights;

        }

        public string CustomerName
        {
            get { return customerName; }
            set { customerName = value; }
        }
        public string CustomerAddress
        {
            get { return customerAddress; }
            set { customerAddress = value; }
        }
        public string CustomerRoomNum
        {
            get { return customerRoomNum; }
            set { customerRoomNum = value; }
        }
        public int StayNights
        {
            get { return stayNights; }
            set { stayNights = value; }
        }

        public override string ToString()
        {
            return  "Customer Name: " + customerName + "Customer Address: " + customerAddress + 
                "Customer Room Number: "  + customerRoomNum + "Number of Nights: " + stayNights + "\n";
        }


        public string FindCustomer(string customerName)
        {
            if(this.customerName.Equals(customerName))
                return this.ToString();

            return "";
        }


        public void serializeAndDeserialzeCustomer(List<Customer> customers)
        {
            //Here we create a FileStream to hold the serialized room
            FileStream fileStream = new FileStream(cfilePath, FileMode.OpenOrCreate);

            //Here we use the CLR's binary formatting support
            SoapFormatter soapFormatter = new SoapFormatter();

            //Here we serialize the objects

            for (int i = 0; i < customers.Count; i++)
                soapFormatter.Serialize(fileStream, customers[i]);


            fileStream.Flush();
            fileStream.Close();



            //Here we retrieve the serialized for room objects
            fileStream = new FileStream(cfilePath, FileMode.Open);

            object customerObj = null;
            string customerName = "Mojeed";
            string result;

            for (; ; )
            {
                try
                {

                    customerObj = soapFormatter.Deserialize(fileStream);



                    //Here we check whether obj is of type Employee
                    //or not and if it is, we type cast it to Employee
                    //and call the GetEmployee() method.
                    if (customerObj is Customer)
                    {
                        result = ((Customer)customerObj).FindCustomer(customerName);

                        if (!string.IsNullOrEmpty(result))
                            Console.WriteLine("Information of Customer with name: " + customerName + ":\n" +
                                Environment.NewLine + result);

                    }


                }
                catch (EndOfStreamException e)
                {
                    Console.WriteLine("No object left!" + e.Message);
                }
                catch (SerializationException)
                {
                    //Console.WriteLine(e.Message);
                    break;
                }

                catch (System.Xml.XmlException)
                {
                    //Console.WriteLine(e.Message);
                    break;
                }

            }

        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Retake_Exam_Q2
{
    public partial class Retake_Exam_Q2_Form : Form
    {
        DialogResult dr;
        Random rand;
        
        public Retake_Exam_Q2_Form()
        {
            InitializeComponent();
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            if (progressBar.Value == progressBar.Maximum)
            {
                timer.Stop();
                progressBar.Value = progressBar.Minimum;

                dr = MessageBox.Show("Start Loop from Beginning YES or NO!", "YES NO", MessageBoxButtons.YesNo, MessageBoxIcon.Information);

                if (dr == DialogResult.Yes)
                {
                    timer.Start();
                }
               
                return;

            }
            else
            {
                               
                progressBar.Value = progressBar.Value + progressBar.Step;
                dateTimeLabel.Text = DateTime.Now.ToString();
                progressBarValueLabel.Text = progressBar.Value.ToString();
                progressBarValueLabel.BackColor = GetRandomColor();

            }
        }

        private void startButton_Click(object sender, EventArgs e)
        {      
            timer.Start();
              
        }

        private Color GetRandomColor()
        {
            rand = new Random();
            return Color.FromArgb(rand.Next(0, 255), rand.Next(0, 255), rand.Next(0, 255));
        }
       
       
    }
}

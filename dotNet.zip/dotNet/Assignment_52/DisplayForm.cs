﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Assignment_52
{
    public partial class FlightInfoDisplayForm : Form
    {
        public string fid;
        public string origin;
        public string dest;
        public string date;
        public string time;

        StringBuilder flightInfo;
        Form1 mainForm;
       
        public FlightInfoDisplayForm(Form1 mainForm)
        {
            InitializeComponent();
            this.mainForm = mainForm;
            flightInfo = new StringBuilder();
           
        }

        public FlightInfoDisplayForm(string fid, string origin, string dest, string date, string time)
        {
            InitializeComponent();

            this.fid = fid;
            this.origin = origin;
            this.dest = dest;
            this.date = date;
            this.time = time;
            
        }

  

        public override string ToString()
        {
            return "Flight_ID: " + fid + " Origin: " + origin + " Destination: " + dest + " Date: "+ date + " Time:" + time;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
           
            //displayTextBox.Text = ToString();
        }

        private void DisplayForm_Load_1(object sender, EventArgs e)
        {
           
            //displayTextBox.Text = Form1.info;
        }


        public void UpdateData(string fid, string origin, string dest, string date, string time)
        {

            flightInfo.Append("Flight_ID: " + fid + " Origin: " + origin + " Destination: " + dest + " Date: " + date + " Time:" + time + Environment.NewLine);

            displayTextBox.Text = flightInfo.ToString();
          
        }

        private void FlightInfoDisplayForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            mainForm.GetFlightInfoDisplayFormCurrentData(flightInfo);
        }
       
    }
}

﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_52
{
    public partial class Form1 : Form
    {
        //public static string fid;
        //public string origin;
        //public string dest;
        //public string date;
        //public string time;

        public static string info;

        FlightInfoDisplayForm displayForm;

        public ArrayList flights = new ArrayList();

        StringBuilder currentFlightInfo;

        public Form1()
        {
            InitializeComponent();

            displayForm = new FlightInfoDisplayForm(this);
            currentFlightInfo = new StringBuilder();
        }

        private void fidTextBox_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void originTextBox_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void destinationTextBox_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void dateTextBox_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void timeTextBox_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        public void GetFlightInfoDisplayFormCurrentData(StringBuilder currentFlightInfo)
        {
            this.currentFlightInfo = currentFlightInfo;

        }

        private void submitButton_Click(object sender, EventArgs e)
        {
            if (displayForm.IsDisposed)
                displayForm = new FlightInfoDisplayForm(this);

            if (displayForm.Visible != true)
                displayForm.Show();


            displayForm.UpdateData(currentFlightInfo.ToString() + fidTextBox.Text, originTextBox.Text,
                destinationTextBox.Text, dateTextBox.Text, timeTextBox.Text);

            
        }

       
    }
}

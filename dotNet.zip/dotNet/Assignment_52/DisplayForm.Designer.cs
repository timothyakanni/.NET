﻿namespace Assignment_52
{
    partial class FlightInfoDisplayForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.displayTextBox = new System.Windows.Forms.TextBox();
            this.summarylabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // displayTextBox
            // 
            this.displayTextBox.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.displayTextBox.Location = new System.Drawing.Point(0, 51);
            this.displayTextBox.Multiline = true;
            this.displayTextBox.Name = "displayTextBox";
            this.displayTextBox.Size = new System.Drawing.Size(563, 210);
            this.displayTextBox.TabIndex = 0;
            this.displayTextBox.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // summarylabel
            // 
            this.summarylabel.AutoSize = true;
            this.summarylabel.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.summarylabel.Location = new System.Drawing.Point(203, 9);
            this.summarylabel.Name = "summarylabel";
            this.summarylabel.Size = new System.Drawing.Size(163, 24);
            this.summarylabel.TabIndex = 1;
            this.summarylabel.Text = "Summary Page";
            // 
            // FlightInfoDisplayForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(563, 261);
            this.Controls.Add(this.summarylabel);
            this.Controls.Add(this.displayTextBox);
            this.Name = "FlightInfoDisplayForm";
            this.Text = "DisplayForm";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FlightInfoDisplayForm_FormClosing);
            this.Load += new System.EventHandler(this.DisplayForm_Load_1);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox displayTextBox;
        private System.Windows.Forms.Label summarylabel;


    }
}
﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Assignment_8
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void loadButton_Click(object sender, EventArgs e)
        {
            articleListBox.DataSource = null;

            ArrayList lst = new ArrayList();

            lst.Add(new Article("On GAs", 34567, 2.34));

            lst.Add(new Article("Evolutionary Computation", 80567, 15.89));

            lst.Add(new Article("Fuzzy Logic", 91567, 23.56));

            //These two lines work only if properties Title and ID

            //and required get and set are defined in class Article

            articleListBox.DisplayMember = "Title";

            articleListBox.ValueMember = "ID";

            articleListBox.Items.Clear();

            articleListBox.DataSource = lst;
        }
    }
}

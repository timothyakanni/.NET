﻿namespace Assignment_8
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.articleGroupBox = new System.Windows.Forms.GroupBox();
            this.sortingGroupBox = new System.Windows.Forms.GroupBox();
            this.articleNameCheckBox = new System.Windows.Forms.CheckBox();
            this.aticleIdCheckBox = new System.Windows.Forms.CheckBox();
            this.articlePriceCheckBox = new System.Windows.Forms.CheckBox();
            this.ascendingRadioButton = new System.Windows.Forms.RadioButton();
            this.descendingRadioButton = new System.Windows.Forms.RadioButton();
            this.noSortingRadioButton = new System.Windows.Forms.RadioButton();
            this.articleListBox = new System.Windows.Forms.ListBox();
            this.sortedArticleListBox = new System.Windows.Forms.ListBox();
            this.loadButton = new System.Windows.Forms.Button();
            this.articleGroupBox.SuspendLayout();
            this.sortingGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // articleGroupBox
            // 
            this.articleGroupBox.Controls.Add(this.articlePriceCheckBox);
            this.articleGroupBox.Controls.Add(this.aticleIdCheckBox);
            this.articleGroupBox.Controls.Add(this.articleNameCheckBox);
            this.articleGroupBox.Location = new System.Drawing.Point(12, 12);
            this.articleGroupBox.Name = "articleGroupBox";
            this.articleGroupBox.Size = new System.Drawing.Size(146, 155);
            this.articleGroupBox.TabIndex = 0;
            this.articleGroupBox.TabStop = false;
            this.articleGroupBox.Text = "ARTICLE";
            // 
            // sortingGroupBox
            // 
            this.sortingGroupBox.Controls.Add(this.noSortingRadioButton);
            this.sortingGroupBox.Controls.Add(this.descendingRadioButton);
            this.sortingGroupBox.Controls.Add(this.ascendingRadioButton);
            this.sortingGroupBox.Location = new System.Drawing.Point(198, 12);
            this.sortingGroupBox.Name = "sortingGroupBox";
            this.sortingGroupBox.Size = new System.Drawing.Size(156, 155);
            this.sortingGroupBox.TabIndex = 1;
            this.sortingGroupBox.TabStop = false;
            this.sortingGroupBox.Text = "SORTING";
            // 
            // articleNameCheckBox
            // 
            this.articleNameCheckBox.AutoSize = true;
            this.articleNameCheckBox.Location = new System.Drawing.Point(24, 31);
            this.articleNameCheckBox.Name = "articleNameCheckBox";
            this.articleNameCheckBox.Size = new System.Drawing.Size(86, 17);
            this.articleNameCheckBox.TabIndex = 2;
            this.articleNameCheckBox.Text = "Article Name";
            this.articleNameCheckBox.UseVisualStyleBackColor = true;
            // 
            // aticleIdCheckBox
            // 
            this.aticleIdCheckBox.AutoSize = true;
            this.aticleIdCheckBox.Location = new System.Drawing.Point(24, 73);
            this.aticleIdCheckBox.Name = "aticleIdCheckBox";
            this.aticleIdCheckBox.Size = new System.Drawing.Size(69, 17);
            this.aticleIdCheckBox.TabIndex = 3;
            this.aticleIdCheckBox.Text = "Article ID";
            this.aticleIdCheckBox.UseVisualStyleBackColor = true;
            // 
            // articlePriceCheckBox
            // 
            this.articlePriceCheckBox.AutoSize = true;
            this.articlePriceCheckBox.Location = new System.Drawing.Point(24, 110);
            this.articlePriceCheckBox.Name = "articlePriceCheckBox";
            this.articlePriceCheckBox.Size = new System.Drawing.Size(82, 17);
            this.articlePriceCheckBox.TabIndex = 4;
            this.articlePriceCheckBox.Text = "Article Price";
            this.articlePriceCheckBox.UseVisualStyleBackColor = true;
            // 
            // ascendingRadioButton
            // 
            this.ascendingRadioButton.AutoSize = true;
            this.ascendingRadioButton.Location = new System.Drawing.Point(24, 33);
            this.ascendingRadioButton.Name = "ascendingRadioButton";
            this.ascendingRadioButton.Size = new System.Drawing.Size(104, 17);
            this.ascendingRadioButton.TabIndex = 2;
            this.ascendingRadioButton.TabStop = true;
            this.ascendingRadioButton.Text = "Ascending Order";
            this.ascendingRadioButton.UseVisualStyleBackColor = true;
            // 
            // descendingRadioButton
            // 
            this.descendingRadioButton.AutoSize = true;
            this.descendingRadioButton.Location = new System.Drawing.Point(24, 74);
            this.descendingRadioButton.Name = "descendingRadioButton";
            this.descendingRadioButton.Size = new System.Drawing.Size(111, 17);
            this.descendingRadioButton.TabIndex = 3;
            this.descendingRadioButton.TabStop = true;
            this.descendingRadioButton.Text = "Descending Order";
            this.descendingRadioButton.UseVisualStyleBackColor = true;
            // 
            // noSortingRadioButton
            // 
            this.noSortingRadioButton.AutoSize = true;
            this.noSortingRadioButton.Location = new System.Drawing.Point(24, 114);
            this.noSortingRadioButton.Name = "noSortingRadioButton";
            this.noSortingRadioButton.Size = new System.Drawing.Size(75, 17);
            this.noSortingRadioButton.TabIndex = 4;
            this.noSortingRadioButton.TabStop = true;
            this.noSortingRadioButton.Text = "No Sorting";
            this.noSortingRadioButton.UseVisualStyleBackColor = true;
            // 
            // articleListBox
            // 
            this.articleListBox.FormattingEnabled = true;
            this.articleListBox.Location = new System.Drawing.Point(12, 221);
            this.articleListBox.Name = "articleListBox";
            this.articleListBox.Size = new System.Drawing.Size(342, 121);
            this.articleListBox.TabIndex = 2;
            // 
            // sortedArticleListBox
            // 
            this.sortedArticleListBox.FormattingEnabled = true;
            this.sortedArticleListBox.Location = new System.Drawing.Point(12, 386);
            this.sortedArticleListBox.Name = "sortedArticleListBox";
            this.sortedArticleListBox.Size = new System.Drawing.Size(342, 121);
            this.sortedArticleListBox.TabIndex = 3;
            // 
            // loadButton
            // 
            this.loadButton.Location = new System.Drawing.Point(12, 192);
            this.loadButton.Name = "loadButton";
            this.loadButton.Size = new System.Drawing.Size(75, 23);
            this.loadButton.TabIndex = 4;
            this.loadButton.Text = "Load";
            this.loadButton.UseVisualStyleBackColor = true;
            this.loadButton.Click += new System.EventHandler(this.loadButton_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(371, 533);
            this.Controls.Add(this.loadButton);
            this.Controls.Add(this.sortedArticleListBox);
            this.Controls.Add(this.articleListBox);
            this.Controls.Add(this.sortingGroupBox);
            this.Controls.Add(this.articleGroupBox);
            this.Name = "MainForm";
            this.Text = "Assignment8";
            this.articleGroupBox.ResumeLayout(false);
            this.articleGroupBox.PerformLayout();
            this.sortingGroupBox.ResumeLayout(false);
            this.sortingGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox articleGroupBox;
        private System.Windows.Forms.CheckBox articleNameCheckBox;
        private System.Windows.Forms.GroupBox sortingGroupBox;
        private System.Windows.Forms.CheckBox articlePriceCheckBox;
        private System.Windows.Forms.CheckBox aticleIdCheckBox;
        private System.Windows.Forms.RadioButton noSortingRadioButton;
        private System.Windows.Forms.RadioButton descendingRadioButton;
        private System.Windows.Forms.RadioButton ascendingRadioButton;
        private System.Windows.Forms.ListBox articleListBox;
        private System.Windows.Forms.ListBox sortedArticleListBox;
        private System.Windows.Forms.Button loadButton;
    }
}


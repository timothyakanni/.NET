﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Database_Ex810
{
    public partial class Form1 : Form
    {

        //In the following we declare objects, which we will need to

        //connect and communicate with the database.

        string connectionString;

        MySqlConnection mySqlConn;

        MySqlDataAdapter mySqlDataAdapter;

        DataSet dataSet;

        public void ShowData()
        {
            try
            {

                connectionString = "datasource=mysql.cc.puv.fi;database=e1100617_examples;username=" + userNameTextBox.Text + ";password=" + passwordTextBox.Text;

                //Here we initialize the mySqlConn object.
                mySqlConn = new MySqlConnection(connectionString);

                //Here we initialize mySqlDataAdapter
                mySqlDataAdapter = new MySqlDataAdapter("Select * from Product", mySqlConn);

                //Here we initialize the dataSet object.
                dataSet = new DataSet();

                //In the following we fill and bind the DataGridView control
                mySqlDataAdapter.Fill(dataSet, "xxx");

                dataGridView1.DataSource = dataSet.Tables["xxx"].DefaultView;


            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        public Form1()
        {
            InitializeComponent();
        }

        private void goButton_Click(object sender, EventArgs e)
        {
            ShowData();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

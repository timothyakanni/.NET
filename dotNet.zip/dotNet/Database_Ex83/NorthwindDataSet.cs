﻿namespace Database_Ex83 {
    
    
    public partial class NorthwindDataSet {
    }
}

namespace Database_Ex83.NorthwindDataSetTableAdapters {
    
    
    public partial class ProductsTableAdapter {
    }
}

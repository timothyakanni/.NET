﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Assignment_61
{
    public partial class MainForm : Form
    {

        string filePathName;

        Stack<string> undoActions = new Stack<string>();
        public MainForm()
        {
            InitializeComponent();

            //mainTextBox.TextChanged += new EventHandler(mainTextBox_TextChanged);
            
            //mainTextBox.KeyDown += new KeyEventHandler(mainTextBox_KeyDown);
           
        }

        private void OpenFile()
        {
            StreamReader sr = File.OpenText(filePathName);
            mainTextBox.Text = sr.ReadToEnd();
            sr.Close();

        }

        private void SaveFile()
        {
            StreamWriter sw = File.CreateText(filePathName);
            sw.WriteLine(mainTextBox.Text);
            sw.Close();

        }

        private void UpdateRecentFileList()
        { //Here we update the list of recent files

            //file1ToolStripMenuItem and file2ToolStripMenuItem

            //are items of Recent DropDownButton

            file2ToolStripMenuItem.Text = file1ToolStripMenuItem.Text;

            file1ToolStripMenuItem.Text = filePathName;

        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Create new text document....");

            mainTextBox.ResetText();
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            openFileDialog.DefaultExt = "txt";

            openFileDialog.InitialDirectory = toolStripFilePathTextBox.Text;

            //Here we make it possible for the user to select .txt or .xml

            //or all files.
            openFileDialog.Filter = "Text Files (*.txt)|*.txt|XML Files (*.xml)|*.xml|All files (*.*)|*.*";

            if (openFileDialog.ShowDialog().Equals(DialogResult.OK))
            {
                filePathName = openFileDialog.FileName;
                OpenFile();

            }

            UpdateRecentFileList();
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // MessageBox .Show( "Saving the file..." ); 

            saveFileDialog.InitialDirectory = filePathName;

            saveFileDialog.Filter = "Text Files (*.txt)|*.txt|XML Files (*.xml)|*.xml|All files (*.*)|*.*";

            if (saveFileDialog.ShowDialog().Equals(DialogResult.OK))
            {

                filePathName = saveFileDialog.FileName;
                toolStripFilePathTextBox.Text = filePathName;

                SaveFile();

                UpdateRecentFileList();
            }


        }

        private void fontToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fontDialog.ShowDialog();

            mainTextBox.Font = fontDialog.Font;

        }

        private void colorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            colorDialog.ShowDialog();

            mainTextBox.ForeColor = colorDialog.Color;
        }

        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(mainTextBox.SelectedText);
        }

        private void cutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(mainTextBox.SelectedText);
            mainTextBox.SelectedText = "";
        }

        private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            mainTextBox.SelectedText = Clipboard.GetText();
        }

        private void file1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            filePathName = file1ToolStripMenuItem.Text;

            if (File.Exists(filePathName))
                OpenFile();
            else
                MessageBox.Show(filePathName + " does not exist!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //StreamReader sr = File.OpenText(pathName);
        }

        private void file2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            filePathName = file2ToolStripMenuItem.Text;

            if (File.Exists(filePathName))
                OpenFile();
            else
                MessageBox.Show(filePathName + " does not exist!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //StreamReader sr = File.OpenText(pathName);


            //Here we update the recent file list

            file2ToolStripMenuItem.Text = file1ToolStripMenuItem.Text;

            file1ToolStripMenuItem.Text = filePathName; 

        }

        private void file3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            filePathName = file3ToolStripMenuItem.Text;

            if (File.Exists(filePathName))
                OpenFile();
            else
                MessageBox.Show(filePathName + " does not exist!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //StreamReader sr = File.OpenText(pathName);

            //Here we update the recent file list

            file3ToolStripMenuItem.Text = file1ToolStripMenuItem.Text;

            file1ToolStripMenuItem.Text = filePathName; 
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Save before exit?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                e.Cancel = false;

            else

            //  "Saving the file..." ); 
            {
                saveFileDialog.InitialDirectory = filePathName;

                saveFileDialog.Filter = "Text Files (*.txt)|*.txt|XML Files (*.xml)|*.xml|All files (*.*)|*.*";

                if (saveFileDialog.ShowDialog().Equals(DialogResult.OK))
                {

                    filePathName = saveFileDialog.FileName;
                    toolStripFilePathTextBox.Text = filePathName;

                    SaveFile();

                    UpdateRecentFileList();
                }
            }               
             
        }

        //Assignment_62 Undo operation
        private void undoToolStripMenuItem_Click(object sender, EventArgs e)
        {            
           //mainTextBox.Undo(); 

            if (undoActions.Count < 1)
            {
                return;
            }

            mainTextBox.Text = undoActions.Pop();

        }
        private void mainTextBox_TextChanged(object sender, EventArgs e)
        {

            //undoActions.Push(mainTextBox.Text);

            //mainTextBox.TextChanged += new EventHandler(mainTextBox_TextChanged);

            //undoActions.Push(mainTextBox.Text);
        }

       
        private void mainTextBox_KeyDown(object sender, KeyEventArgs e)
        {

            undoActions.Push(mainTextBox.Text);

            //mainTextBox.KeyDown += new KeyEventHandler(mainTextBox_KeyDown);

        //    if (e.KeyCode == Keys.Z && (e.Control))
        //    {
        //        mainTextBox.Text = undoActions.Pop();
        //    }          
            

        }

        //Assignment 63 start here for find and replace function
        private void searchButton_Click(object sender, EventArgs e)
        {
            
           
            if (searchTextBox.Text.Length > 0)
            {
                
                int index = 0;                    

                while (index < mainTextBox.Text.LastIndexOf(searchTextBox.Text))
                {

                    mainTextBox.Find(searchTextBox.Text, index, mainTextBox.TextLength, RichTextBoxFinds.None);
                    mainTextBox.SelectionBackColor = Color.Red;
                    index = mainTextBox.Text.IndexOf(searchTextBox.Text, index) + 1;                    

                }

                
            }
        }
        

        private void replaceButton_Click(object sender, EventArgs e)
        {
            if (replaceTextBox.Text.Length > 0)
            {

                int index = 0;
                while (index < mainTextBox.Text.LastIndexOf(searchTextBox.Text))
                {

                    mainTextBox.Find(searchTextBox.Text, index, mainTextBox.TextLength, RichTextBoxFinds.None);
                    mainTextBox.SelectionBackColor = Color.Red;
                    mainTextBox.SelectedText = replaceTextBox.Text;
                    index = mainTextBox.Text.IndexOf(searchTextBox.Text, index) + 1;

                }
               

            }
        }



    }
}

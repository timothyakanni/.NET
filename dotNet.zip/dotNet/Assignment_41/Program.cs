﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_41
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Room> rooms = new List<Room>();
            rooms.Add(new Room("R100","45 Square meter","Single",13.02,"Room with TV"));
            rooms.Add(new Room("R200", "50 Square meter", "Double", 15.02, "Room with smoking area"));
            rooms.Add(new Room("R300", "35 Square meter", "Double", 19.02, "Room with Balcony"));
            rooms.Add(new Room("R400", "25 Square meter", "Single", 20.02, "Room with direct TV"));
            rooms.Add(new Room("R500", "50 Square meter", "Double", 16.02, "Room with Sauna"));

            List<Customer> customers = new List<Customer>();
            customers.Add(new Customer("Julius","Aventie", "R100",4));
            customers.Add(new Customer("Mojeed", "Palossari", "R200", 2));
            customers.Add(new Customer("Steve", "Aventie", "R300", 1));
            customers.Add(new Customer("Sabin", "Aventie", "R400", 3));
            customers.Add(new Customer("Akanni", "Olympia", "R500", 5));           

            Hotel H1 = new Hotel("Amarillo", "65100, Vaasa, FI", 3, new DateTime(2015, 3, 12, 10, 15, 0, 0),rooms, customers);
            Hotel H2 = new Hotel("Tekla", "65300, Vaasa, FI", 5, new DateTime(2015, 3, 12, 10, 15, 0, 0),rooms, customers);

            //Here we test writing methods for rooms and customers
            for (int i= 0; i < rooms.Count; i++ )
                rooms[i].writeRoomToText(rooms);

           
            for (int i = 0; i < customers.Count; i++)
                customers[i].writeCustomerToText(customers);

            Console.WriteLine("------Reading Room and Customer from text----------");
            //Here we test reading methods for rooms and customers
                rooms[3].readRoomFromText("R100");

            //for (int i = 0; i < customers.Count; i++)
                customers[3].readCustomerFromText("Julius"); 
            
            Console.WriteLine("------Testing search method for Room and Customer-------");

            //Here we test search methods for rooms and Customers
            for (int i = 0; i < rooms.Count; i++)
            {
                if (rooms[i].searchRoom("R100"))
                    Console.WriteLine(rooms[i]);
            }

            for (int i = 0; i < customers.Count; i++)
            {
                if (customers[i].searchCustomer("Julius"))
                    Console.WriteLine(customers[i]);            

            } 


                
        }

       
    }
}

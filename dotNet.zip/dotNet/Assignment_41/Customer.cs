﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_41
{
   
    class Customer
    {

        protected string customerName;

        protected string customerAddress;

        protected string customerRoomNum;

        protected int stayNights;

        public DateTime arrivalDate = DateTime.Parse("08.2.2010 12:30");

        string filePath = @"U:\Temp\customers.txt";

        public Customer(string customerName, string customerAddress, string customerRoomNum,
            int stayNights)
        {
            this.customerName = customerName;
            this.customerAddress = customerAddress;
            this.customerRoomNum = customerRoomNum;
            this.stayNights = stayNights;

        }

        public string CustomerName
        {
            get { return customerName; }
            set { customerName = value; }
        }
        public string CustomerAddress
        {
            get { return customerAddress; }
            set { customerAddress = value; }
        }
        public string CustomerRoomNum
        {
            get { return customerRoomNum; }
            set { customerRoomNum = value; }
        }
        public int StayNights
        {
            get { return stayNights; }
            set { stayNights = value; }
        }

        public override string ToString()
        {
            return  "Customer Name: " + customerName + "Customer Address: " + customerAddress + 
                "Customer Room Number: "  + customerRoomNum + "Number of Nights: " + stayNights + "\n";
        }



        public void writeCustomerToText(List<Customer> customers)
        {
            
            TextWriter textWriter;
            textWriter = new StreamWriter(filePath);
            

            try
            {              

                for (int i = 0; i < customers.Count; i++)
                {
                    textWriter.Write(customers[i].customerName + " ");
                    textWriter.Write(customers[i].customerAddress + " ");
                    textWriter.Write(customers[i].customerRoomNum + " ");
                    textWriter.WriteLine(customers[i].stayNights + ";");
                }
            }
            catch (FileNotFoundException e)
            {
                Console.WriteLine(e.Message + "\nCannot open " + filePath);
                
            } catch (IOException e)
            {
                Console.WriteLine(e.Message + "\nWrite error.");
            }

            textWriter.Close();

            //Console.Write("Customers info are written succefully..");
           

        }

        public void readCustomerFromText(string customerName)
        {
            TextReader textReader;

            // Here we open the file for reading. 
            try
            {
                textReader = new StreamReader(filePath);

            }
            catch (FileNotFoundException e)
            {
                Console.Write(e.Message + "\nCannot open " + filePath);
                return;
            }

            string customerItem;
            bool customerFound = false;


            try
            {

                while ((customerItem = textReader.ReadLine()) != null)
                {
                    char[] delimiterChars = { ' ', ';' };
                    string[] info = customerItem.Split(delimiterChars);

                    foreach (string i in info)
                        

                    if (info[0].Equals(customerName))
                    {

                        Console.WriteLine(info[0] + " " + info[1] + " " + info[2] + " " + info[3]);

                        customerFound = true;
                        break;
                    }

                }


                textReader.Close();


                if (customerFound == false)
                    Console.Write(customerName + " was not found.");
            }
            catch (IOException e)
            {
                Console.Write(e.Message + "Read error.");
            }


        }

        //Here we define search method for customer

        public bool searchCustomer(string customerName)
        {
            if(this.customerName.Equals(customerName))
                    return true;

            return false;
        }


    }
}

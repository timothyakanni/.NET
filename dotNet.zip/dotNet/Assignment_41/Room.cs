﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_41
{

   
    class Room
    {

        protected string roomNum;

        protected string area;

        protected string type;

        protected double price;

        protected string descript;

        string filePath = @"U:\Temp\rooms.txt";

        public Room(string roomNum, string area, string type, double price, string descript)
        {
            this.roomNum = roomNum;
            this.area = area;
            this.type = type;
            this.price = price;
            this.descript = descript;

        }

        public Room()
        {
            this.roomNum = "";
            this.area = "";
            this.type = "";
            this.price = 0.00;
            this.descript = "";

        }

        public string RoomNum
        {
            get { return roomNum; }
            set { roomNum = value; }
        }
        public string Area
        {
            get { return area; }
            set { area = value; }
        }
        public string Type
        {
            get { return type; }
            set { type = value; }
        }
        public double Price
        {
            get { return price; }
            set { price = value; }
        }
        public string Descript
        {
            get { return descript; }
            set { descript = value; }
        }

        public override string ToString()
        {
            return " Room Number: " + roomNum + " Area: " + area + " Type: " + type +
                " Price: " + price + " Description: " + descript + "\n";
        }


        public void writeRoomToText(List<Room> rooms)
        {
            //Here we declare the text writer and reader objects
            TextWriter textWriter;
            textWriter = new StreamWriter(filePath);

            try
            {
                
                

                for (int i = 0; i < rooms.Count; i++)
                {
                    //textWriter.Write(rooms[i]);
                    textWriter.Write(rooms[i].roomNum + " ");
                    textWriter.Write(rooms[i].area + " ");
                    textWriter.Write(rooms[i].type + " ");
                    textWriter.Write(rooms[i].price + " ");
                    textWriter.WriteLine(rooms[i].descript + ";");


                }
            }
            catch (IOException e)
            {
                Console.WriteLine(e.Message + "\nCannot open " + filePath);

            }

            textWriter.Close();

            //return "Text saved to the file";


        }

        public void readRoomFromText(string roomNum)
        {
            TextReader textReader;
            string roomItem;
            bool roomItemFound = false;

            // Here we open the file for reading. 
            try
            {
                textReader = new StreamReader(filePath);

                while ((roomItem = textReader.ReadLine()) != null)
                {
                    char[] delimiterChars = { ' ', ';' };
                    string[] info = roomItem.Split(delimiterChars);

                    foreach (string i in info)
                    {
                        //Console.Write(i + " ");
                        //Console.Write (Environment.NewLine + "---------" + Environment.NewLine);

                        if (i.Equals(roomNum))
                        {

                            Console.WriteLine(info[0] + " " + info[1] + " " + info[2] + " " + info[3] + " " + info[4]);
                            //Console.Write(i);
                            roomItemFound = true;
                            break;
                        }
                    }
                   
                }

                textReader.Close();

                if (roomItemFound == false)
                    Console.Write(roomNum + " was not found.");

            }
            catch (FileNotFoundException e)
            {
                Console.Write(e.Message + "\nCannot open " + filePath);
                return;
            }

            catch (IOException e)
            {
                Console.Write(e.Message + "Read error.");
            }

        }

        //Here we define search method for room
        public bool searchRoom(string roomNum)
        {
            
            if (this.roomNum.Equals(roomNum))
                return true;

            return false;
        }



    }
}

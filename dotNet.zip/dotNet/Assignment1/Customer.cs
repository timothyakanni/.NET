﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1

{  
        class Customer
        {

            string name;

            string cId;

            string cFlightId;


            public Customer(string name, string cId, string cFlightId)
            {
                this.name = name;

                this.cId = cId;

                this.cFlightId = cFlightId;

            }

            public override string ToString()
            {

                return name + " " + cId + " " + cFlightId;

            }            

            public bool CustomerFound(string Cid)
            {

                return (this.cId.Equals(Cid));

            }

            public bool FlightCustomerFound(string fid)
            {

                return (this.cFlightId.Equals(fid));

            }

            //This is the most important method
            public string GetCustomerInfo(ArrayList flights)
            {

                string flightInfo = "";

                foreach (Flight f in flights)
                {

                    flightInfo = f.GetFlightInfo(this.cFlightId);

                    if (flightInfo.Length > 0)
                        break;
                }

                return name + " " + cId + " " + flightInfo;

            }


        }

    
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;


namespace Assignment1

{
    class Program
    {
        static void Main(string[] args)
        {


            ArrayList customers = new ArrayList();
            customers.Add(new Customer("Charlie", "C100", "F100"));
            customers.Add(new Customer("Julius", "C200", "F200"));
            customers.Add(new Customer("Mojeed", "C300", "F300"));
            customers.Add(new Customer("Seppo", "C400", "F500"));
            customers.Add(new Customer("Laura", "C500", "F200"));

            ArrayList flights = new ArrayList();
            flights.Add(new Flight("F100", "FI", "NS", new DateTime(2015 , 3 , 12 , 10 , 15 , 0, 0)));
            flights.Add(new Flight("F200", "CA", "NY", new DateTime(2015, 5, 12, 10, 15, 0, 0)));
            flights.Add(new Flight("F300", "FI", "SW", new DateTime(2015, 7, 12, 10, 15, 0, 0)));
            flights.Add(new Flight("F400", "GER", "NS", new DateTime(2015, 8, 12, 10, 15, 0, 0)));
            flights.Add(new Flight("F500", "FI", "SA", new DateTime(2015, 10, 12, 10, 15, 0, 0)));




            Console.WriteLine(" ");
            Console.Write("---Here We print Customer with given Customer ID----");

            Console.WriteLine(" ");
            Console.Write("Type Customer ID: ");
            string cId = Console.ReadLine();
            
            foreach( Customer c in customers){

                if(c.CustomerFound(cId)){
                  Console.WriteLine( c.GetCustomerInfo(flights));
                }

                
            } Console.WriteLine("Not Found");


            Console.WriteLine(" ");
            Console.Write("---Here We print flight Info Flight ID----");

            Console.WriteLine(" ");
            Console.Write("Type Flight ID: ");
            string fId = Console.ReadLine();

            foreach (Flight f in flights)
            {

                if (f.FlightFound(fId))
                {
                    Console.WriteLine(f.GetFlightInfo(fId));
                }
            } Console.WriteLine("Not Found");
            

           
        }
    }
}

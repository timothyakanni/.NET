﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class Flight
    {

        string flightId;

        string origin;

        string dest;

        DateTime date = DateTime.Parse("10.2.2010 12:30");

        public Flight(string flightId, string origin, string dest, DateTime date)
        {
            this.flightId = flightId;

            this.origin = origin;

            this.dest = dest;

            this.date = date;
           

        }

        public override string ToString()
        {

            return flightId + " " + origin + " " + dest + " " + date;

        }

        public bool FlightFound(string flightId)
        {
            
            return (this.flightId.Equals(flightId));            
          
        }


        public string GetFlightInfo(string CflightId)
        {
            if (this.flightId.Equals(CflightId))

                return flightId + " " + origin + " " + dest + " " + date;

            return "";

        }


    }
}

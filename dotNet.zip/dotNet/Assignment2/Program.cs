﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Assignment2
{
    class Program
    {
        static void Main(string[] args)
        {

            Concert[] concerts = new Concert[5];
            concerts[0] = new Concert("Music", "Finland", 20.50, new DateTime(2015 , 3 , 12 , 10 , 15 , 0, 0));
            concerts[1] = new Concert("Video", "Canada", 50.50, new DateTime(2015, 5, 12, 10, 15, 0, 0));
            concerts[2] = new Concert("Movie", "Sweden", 10.50, new DateTime(2015, 7, 12, 10, 15, 0, 0));
            concerts[3] = new Concert("Play", "Germany", 100.00, new DateTime(2015, 8, 12, 10, 15, 0, 0));
            concerts[4] = new Concert("Party", "Norway", 75.00, new DateTime(2015, 10, 12, 10, 15, 0, 0));

            //Here we define Hashtable object and initialize it

            Hashtable concert = new Hashtable();
            
            concert.Add("Music", concerts[0].ToString());
            concert.Add("Video", concerts[1].ToString());
            concert.Add("Movie", concerts[2].ToString());
            concert.Add("Play", concerts[3].ToString());
            concert.Add("Party", concerts[4].ToString());  
           
            //Here we print the full content of the Hashtable
            Console.Write("----Here We print full content of Hashtable-----");
            Console.WriteLine(" ");
            Console.WriteLine(" ");
            foreach (string title in concert.Keys)
                Console.WriteLine(title + " --> " + concert[title]);

            //Here we test defined operators in class
            
            //Here we test increment method
            concerts[0]++;
            concerts[1]++;
            concerts[2]++;           
            Console.WriteLine(" ");
            Console.WriteLine("Concerts Prices after incrementation by 5 : ");
            Console.WriteLine(concerts[0]);
            Console.WriteLine(concerts[1]);
            Console.WriteLine(concerts[2]);


            //Here we test decrement method
            concerts[3]--;
            concerts[4]--;
            Console.WriteLine(" ");
            Console.WriteLine("Concerts Prices after decremetation by 5 : ");
            Console.WriteLine(concerts[3]);
            Console.WriteLine(concerts[4]);

            //Here we test less than and greater than method
            Console.WriteLine(" ");
            Console.WriteLine("Concert 1 < Concert 2? : " + (concerts[0] < concerts[1]));           

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assignment2
{
    class Concert
    {

        string title;

        string location;

        double unitPrice;

        DateTime date = DateTime.Parse("10.2.2010 12:30");

        // here we define Constructor method for the class
        public Concert(string title, string location,  double unitPrice, DateTime date)
        {
            this.title = title;

            this.location = location;

            this.unitPrice = unitPrice;

            this.date = date;           

        }

        // here we define to string method for the class
        public override string ToString()
        {

            return title + " " + location + " " + unitPrice + " " + date;

        }

        //here we define < operator overloading for the class
        public static bool operator <(Concert c1, Concert c2)
        {

            if (c1.unitPrice < c2.unitPrice)

                return true;

            return false;

        }

        public static bool operator >(Concert c1, Concert c2)
        {

            if (c1.unitPrice > c2.unitPrice)

                return true;

            return false;

        }

        //here we define increment ++ operator overloading for the class        
        public static Concert operator ++(Concert c1)
        {

            return new Concert(c1.title, c1.location, c1.unitPrice+=5, c1.date);

        }

        //here we define decrement -- operator overloading for the class  
        public static Concert operator --(Concert c1)
        {

            return new Concert(c1.title, c1.location, c1.unitPrice-=5, c1.date);

        }


    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Database_Ex88
{
    public partial class Form1 : Form
    {
        string connectionString;

        OleDbConnection oleDbConnection;

        OleDbCommand oleDbCommand;

        OleDbDataAdapter oleDbDataAdapter;

        DataSet dataSet;

        public Form1()
        {
            InitializeComponent();
        }

        private void getDataButton_Click(object sender, EventArgs e)
        {
            connectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=U:\Northwind.mdb;Persist Security Info=False";

            oleDbConnection = new OleDbConnection(connectionString);

            // OleDbConnection myOleDbConnection = new OleDbConnection("server=localhost;database=Northwind;uid=sa;pwd=sa");

            oleDbCommand = oleDbConnection.CreateCommand();

            oleDbCommand.CommandText = "SELECT FirstName, LastName, EmployeeID FROM Employees";

            oleDbDataAdapter = new OleDbDataAdapter();

            oleDbDataAdapter.SelectCommand = oleDbCommand;

            //Here we open the connection

            oleDbConnection.Open();

            //Here we create an instance of DataSet.            

            dataSet = new DataSet();

            //Here we create Employees table in the dataSet object and fill it with the results of the query

            oleDbDataAdapter.Fill(dataSet, "Emps");

            //oleDbDataAdapter.Fill(dataSet, "Empsx");

            //Here we set the data source of dataGridView1 to Employees table

            //of the dataSet object

            dataGridView.DataSource = dataSet.Tables["Emps"].DefaultView;

            //Here we close the connection

            oleDbConnection.Close();
        }


    }
}

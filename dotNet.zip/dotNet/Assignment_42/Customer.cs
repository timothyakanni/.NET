﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_42
{
   
    class Customer
    {

        protected string customerName;

        protected string customerAddress;

        protected string customerRoomNum;

        protected int stayNights;

        public DateTime arrivalDate = DateTime.Parse("08.2.2010 12:30");

        string filePath = @"U:\Temp\customers.dat";

        public Customer(string customerName, string customerAddress, string customerRoomNum,
            int stayNights)
        {
            this.customerName = customerName;
            this.customerAddress = customerAddress;
            this.customerRoomNum = customerRoomNum;
            this.stayNights = stayNights;

        }

        public string CustomerName
        {
            get { return customerName; }
            set { customerName = value; }
        }
        public string CustomerAddress
        {
            get { return customerAddress; }
            set { customerAddress = value; }
        }
        public string CustomerRoomNum
        {
            get { return customerRoomNum; }
            set { customerRoomNum = value; }
        }
        public int StayNights
        {
            get { return stayNights; }
            set { stayNights = value; }
        }

        public override string ToString()
        {
            return  "Customer Name: " + customerName + "Customer Address: " + customerAddress + 
                "Customer Room Number: "  + customerRoomNum + "Number of Nights: " + stayNights + "\n";
        }



        public void writeCustomerToBinary(List<Customer> customers)
        {
            
            BinaryWriter binaryWriter;
            binaryWriter = new BinaryWriter(new FileStream(filePath, FileMode.OpenOrCreate));
            

            try
            {              

                for (int i = 0; i < customers.Count; i++)
                {
                    binaryWriter.Write(customers[i].customerName);
                    binaryWriter.Write(customers[i].customerAddress);
                    binaryWriter.Write(customers[i].customerRoomNum);
                    binaryWriter.Write(customers[i].stayNights);
                   

                }
            }
            catch (FileNotFoundException e)
            {
                Console.WriteLine(e.Message + "\nCannot open " + filePath);
                
            } catch (IOException e)
            {
                Console.WriteLine(e.Message + "\nWrite error.");
            }

            binaryWriter.Close();

            //Console.Write("Customers info are written succefully..");
           

        }

        public void readCustomerFromBinary(string customerName)
        {
            BinaryReader binaryReader;

            // Here we open the file for reading. 
            try
            {
                binaryReader = new BinaryReader(new FileStream(filePath, FileMode.Open));

                for (; ; )
                {

                    string customerNameBinary = binaryReader.ReadString();
                    string customerAddressBinary = binaryReader.ReadString();
                    string customerRoomNumBinary = binaryReader.ReadString();
                    int stayNightsBinary = binaryReader.ReadInt16();

                    if (customerNameBinary.Equals(customerName))
                    {

                        Console.WriteLine(customerNameBinary + " " + customerAddressBinary + " "
                            + customerRoomNumBinary + " " + stayNightsBinary);

                       
                        break;
                    }

                }


                binaryReader.Close();


                

            }catch(EndOfStreamException e){
                Console.Write(e.Message + customerName + " was not found.");
            }
            catch (FileNotFoundException e){
                Console.Write(e.Message + "\nCannot open " + filePath);
                return;
            }
            catch (IOException e){
                Console.Write(e.Message + "Read error.");
            }


        }

       


    }
}

﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_42
{

   
    class Room
    {

        protected string roomNum;

        protected string area;

        protected string type;

        protected double price;

        protected string descript;

        string filePath = @"U:\Temp\rooms.dat";

        public Room(string roomNum, string area, string type, double price, string descript)
        {
            this.roomNum = roomNum;
            this.area = area;
            this.type = type;
            this.price = price;
            this.descript = descript;

        }

        public Room()
        {
            this.roomNum = "";
            this.area = "";
            this.type = "";
            this.price = 0.00;
            this.descript = "";

        }

        public string RoomNum
        {
            get { return roomNum; }
            set { roomNum = value; }
        }
        public string Area
        {
            get { return area; }
            set { area = value; }
        }
        public string Type
        {
            get { return type; }
            set { type = value; }
        }
        public double Price
        {
            get { return price; }
            set { price = value; }
        }
        public string Descript
        {
            get { return descript; }
            set { descript = value; }
        }

        public override string ToString()
        {
            return " Room Number: " + roomNum + " Area: " + area + " Type: " + type +
                " Price: " + price + " Description: " + descript + "\n";
        }


        public void writeRoomToBinary(List<Room> rooms)
        {
            //Here we declare the text writer and reader objects
            BinaryWriter binaryWriter;
            binaryWriter = new BinaryWriter(new FileStream(filePath, FileMode.OpenOrCreate));

            try
            {
                
                

                for (int i = 0; i < rooms.Count; i++)
                {
                    //textWriter.Write(rooms[i]);
                    binaryWriter.Write(rooms[i].roomNum);
                    binaryWriter.Write(rooms[i].area);
                    binaryWriter.Write(rooms[i].type);
                    binaryWriter.Write(rooms[i].price);
                    binaryWriter.Write(rooms[i].descript);
                    

                }
            }
            catch (IOException e)
            {
                Console.WriteLine(e.Message + "\nCannot open " + filePath);

            }

            binaryWriter.Close();

            //return "Text saved to the file";


        }

        public void readRoomFromBinary(string roomNum)
        {
            BinaryReader binaryReader;
           

            // Here we open the file for reading. 
            try
            {
                binaryReader = new BinaryReader(new FileStream(filePath, FileMode.Open));

               for(;;)
                {
                  
                    string roomNumBinary = binaryReader.ReadString();
                    string areaBinary = binaryReader.ReadString();
                    string typeBinary = binaryReader.ReadString();
                    double priceBinary = binaryReader.ReadDouble();
                    string descriptBinary = binaryReader.ReadString();
                    {
                        //Console.Write(i + " ");
                        //Console.Write (Environment.NewLine + "---------" + Environment.NewLine);

                        if (roomNumBinary.Equals(roomNum))
                        {

                            Console.WriteLine(roomNumBinary + " " + areaBinary+ " " + typeBinary + " " + priceBinary
                                + " " + descriptBinary);                            
                            
                            break;
                        }
                    }
                   
                }

                binaryReader.Close();

                

            }catch(EndOfStreamException e){
                 Console.WriteLine(e.Message + roomNum + " was not found.");
            }          
            catch (IOException e)
            {
                Console.WriteLine(e.Message + "Read error.");
            }

        }

        


    }
}

﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace Assignment_31
{
      
    class Program
    {
        static void Main(string[] args)
        {


            Flight  flight = new Flight();

            flight[0] = new Flight(100, "FI", "NS", 50.75, new DateTime(2015, 3, 12, 10, 15, 0));
            flight[1] = new Flight(200, "CA", "NY", 30.50, new DateTime(2015, 5, 12, 10, 15, 0));
            flight[2] = new Flight(300, "FI", "SW", 20.25, new DateTime(2015, 7, 12, 10, 15, 0));

            Console.Write("---Here We print flight Info Flight ID----");

            Console.WriteLine(" ");
            Console.Write("Type Flight ID: ");
            int fId = Int16.Parse(Console.ReadLine());
            Console.WriteLine(fId);

            Console.Write(flight.GetFlightInfo(fId));
            Console.WriteLine(" ");

        }  
    }
}

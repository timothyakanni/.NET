﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assignment_31
{
    class Flight
    {
        public readonly string companyName;

        int id;

        string origin;

        string dest;

        double price;

        DateTime date = DateTime.Parse("10.2.2010 12:30");


        private ArrayList flightObjs;



        public Flight()
        {
            flightObjs = new ArrayList();
        }

        //this is constructor
        public Flight(int id, string origin, string dest, double price, DateTime date)
        {
            this.companyName = "FINNAIR";
            this.id = id;
            this.origin = origin;
            this.dest = dest;
            this.price = price;
            this.date = date;

        }

        public override string ToString()
        {
            return companyName + " " + id + " " + origin + " " + dest + " "
                + price + " " + date;
        }

        public string GetFlightInfo(int id)
        {


            foreach (Flight f in flightObjs)
            {

                if (f.id == id)

                    return f.ToString();

            }

            return "Incorrect Flight ID";


        }

        public bool GetFlight(int id)
        {

            foreach (Flight f in flightObjs)
            {

                if (f.id == id)

                    return true;

            }

            return false;
        }

        //Here we define indexer for the class
        public Flight this[int index]
        {

            set
            {
                flightObjs.Add(value);

            }

            get
            {
                return (Flight)flightObjs[index];

            }

        }


    }
}

﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Assignment_44
{
   
    class Customer
    {

        protected string customerName;

        protected string customerAddress;

        protected string customerRoomNum;

        protected int stayNights;

        public DateTime arrivalDate = DateTime.Parse("08.2.2010 12:30");
        
        

        public Customer(string customerName, string customerAddress, string customerRoomNum,
            int stayNights)
        {
            this.customerName = customerName;
            this.customerAddress = customerAddress;
            this.customerRoomNum = customerRoomNum;
            this.stayNights = stayNights;

        }

        public string CustomerName
        {
            get { return customerName; }
            set { customerName = value; }
        }
        public string CustomerAddress
        {
            get { return customerAddress; }
            set { customerAddress = value; }
        }
        public string CustomerRoomNum
        {
            get { return customerRoomNum; }
            set { customerRoomNum = value; }
        }
        public int StayNights
        {
            get { return stayNights; }
            set { stayNights = value; }
        }

        public override string ToString()
        {
            return  "Customer Name: " + customerName + "Customer Address: " + customerAddress + 
                "Customer Room Number: "  + customerRoomNum + "Number of Nights: " + stayNights + "\n";
        }


        public string FindCustomer(string customerName)
        {
            if(this.customerName.Equals(customerName))
                return this.ToString();

            return "";
        }

        public void customerXmlWriter(List<Customer> customers)
        {


            XmlTextWriter xmlTextWriter = new XmlTextWriter(@"U:\Temp\customer1.txt", System.Text.Encoding.UTF8);
            xmlTextWriter.Formatting = Formatting.Indented;
            //Here we write XML declaration
            xmlTextWriter.WriteStartDocument();
            //Here we write the root elemnt
            xmlTextWriter.WriteStartElement("Customers");

            for (int i = 0; i < customers.Count; i++)
            {

                //Here we write the first employee
                xmlTextWriter.WriteStartElement("Customer");
                //Here we define an attribute with namespace for the element.

                xmlTextWriter.WriteElementString("CustomerName", customers[i].customerName);
                xmlTextWriter.WriteElementString("CustomerAddress", customers[i].customerAddress);
                xmlTextWriter.WriteElementString("CustomerRoomNumber", customers[i].customerRoomNum);
                xmlTextWriter.WriteElementString("StayNights", (customers[i].stayNights).ToString());
                
                xmlTextWriter.WriteEndElement();
                
            }

            //Here we end the root element
            xmlTextWriter.WriteEndElement();
            //Here we end the document element
            xmlTextWriter.WriteEndDocument();
            //Here we flush and close the stream
            xmlTextWriter.Flush();
            xmlTextWriter.Close();

            Console.WriteLine("Customers have been written to XML successfully....");
        }

        public void customerXmlReader()
        {

            string filePath = @"U:\Temp\customer1.txt";

            XmlTextReader reader = new XmlTextReader(filePath);
            reader.WhitespaceHandling = WhitespaceHandling.None;

            while (reader.Read())
            {
                switch (reader.NodeType)
                {
                    case XmlNodeType.Element: // The node is an element.
                        Console.Write("<" + reader.Name);
                        Console.Write(">");
                        break;
                    case XmlNodeType.Text: //Display the text in each element.
                        Console.Write(reader.Value);
                        break;
                    case XmlNodeType.EndElement: //Display the end of the element.
                        Console.Write("</" + reader.Name);
                        Console.WriteLine(">");
                        break;
                }

            }

            reader.Close();
        }
        

    }
}

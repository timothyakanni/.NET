﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Xml;


namespace Assignment_44
{

    class Room
    {

        protected string roomNum;

        protected string area;

        protected string type;

        protected double price;

        protected string descript;

       

        public Room(string roomNum, string area, string type, double price, string descript)
        {
            this.roomNum = roomNum;
            this.area = area;
            this.type = type;
            this.price = price;
            this.descript = descript;

        }

        public Room()
        {
            this.roomNum = "";
            this.area = "";
            this.type = "";
            this.price = 0.00;
            this.descript = "";

        }

        public string RoomNum
        {
            get { return roomNum; }
            set { roomNum = value; }
        }
        public string Area
        {
            get { return area; }
            set { area = value; }
        }
        public string Type
        {
            get { return type; }
            set { type = value; }
        }
        public double Price
        {
            get { return price; }
            set { price = value; }
        }
        public string Descript
        {
            get { return descript; }
            set { descript = value; }
        }

        public override string ToString()
        {
            return " Room Number: " + roomNum + " Area: " + area + " Type: " + type +
                " Price: " + price + " Description: " + descript + "\n";
        }

        public string FindRoom(string roomNum)
        {

            if (this.roomNum.Equals(roomNum))
                return this.ToString();

            return "";
        }

        public void roomXmlWriter(List<Room> rooms)
        {
           

            XmlTextWriter xmlTextWriter = new XmlTextWriter(@"U:\Temp\room1.txt", System.Text.Encoding.UTF8);
            xmlTextWriter.Formatting = Formatting.Indented;
            //Here we write XML declaration
            xmlTextWriter.WriteStartDocument();
            //Here we write the root elemnt
            xmlTextWriter.WriteStartElement("rooms");

             for (int i = 0; i < rooms.Count; i++) { 

            //Here we write the first employee
            xmlTextWriter.WriteStartElement("room");
            //Here we define an attribute with namespace for the element.

            xmlTextWriter.WriteElementString("RoomNumber", rooms[i].roomNum);
            xmlTextWriter.WriteElementString("Area", rooms[i].area);
            xmlTextWriter.WriteElementString("Type", rooms[i].type);
            xmlTextWriter.WriteElementString("Price", (rooms[i].price).ToString());
            xmlTextWriter.WriteElementString("Description", rooms[i].descript);
            xmlTextWriter.WriteEndElement();  
                 
            }

             //Here we end the root element
             xmlTextWriter.WriteEndElement();
             //Here we end the document element
             xmlTextWriter.WriteEndDocument();
             //Here we flush and close the stream
             xmlTextWriter.Flush();
             xmlTextWriter.Close();

             Console.WriteLine("Rooms have been written to XML successfully....");
        }

        public void roomXmlReader()
        {

            string filePath = @"U:\Temp\room1.txt";

            XmlTextReader reader = new XmlTextReader(filePath);
            reader.WhitespaceHandling = WhitespaceHandling.None;

            while (reader.Read())
            {
                switch (reader.NodeType)
                {
                    case XmlNodeType.Element: // The node is an element.
                        Console.Write("<" + reader.Name);
                        Console.Write(">");
                        break;
                    case XmlNodeType.Text: //Display the text in each element.
                        Console.Write(reader.Value);
                        break;
                    case XmlNodeType.EndElement: //Display the end of the element.
                        Console.Write("</" + reader.Name);
                        Console.WriteLine(">");
                        break;
                }

            }

            reader.Close();
        }


    }
}




﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_44
{
    class Hotel
    {

        protected string hotelName;

        protected string hotelAddress;

        protected int hotelStarsNum;

        public DateTime hotelConstrDate = DateTime.Parse("10.2.2010 12:30");

        List<Room> roomsObj;

        List<Customer> customersObj;

        public Hotel(string hotelName, string hotelAddress, int hotelStarsNum, DateTime hotelConstrDate,
            List<Room> roomsObj, List<Customer> customersObj)
        {
            this.hotelName = hotelName;
            this.hotelAddress = hotelAddress;
            this.hotelStarsNum = hotelStarsNum;
            this.hotelConstrDate = hotelConstrDate;
            this.roomsObj = roomsObj;
            this.customersObj = customersObj;

        }
        public string HotelName
        {
            get { return hotelName; }
            set { hotelName = value; }
        }

        public string HotelAddress
        {
            get { return hotelAddress; }
            set { hotelAddress = value; }
        }
        public int HotelStarsNum
        {
            get { return hotelStarsNum; }
            set { hotelStarsNum = value; }
        }

        public override string ToString()
        {
            string roomInfo = "";
            string customerInfo = "";

            foreach (Room r in roomsObj)
            {
                roomInfo += r.ToString();
            }

            foreach (Customer c in customersObj)
            {
                customerInfo += c.ToString();
            }

            return "Hotel Info:=> \n" + "Hotel Name: " + HotelName + "Hotel Address: " + HotelAddress + "Hotel Star Number: " 
                + hotelStarsNum + "Hotel Construction Date: " + hotelConstrDate +

                  "\n\n" + "Rooms info:=> " + roomInfo  +
    
                  "\n\n" + "Customers info:=> " + customerInfo + "\n";
        }       

        public string searchHotelInfo(string hotelName)
        {
            if (this.hotelName.Equals(hotelName))
                return this.ToString();
            else
                return "";
        }

    }
}

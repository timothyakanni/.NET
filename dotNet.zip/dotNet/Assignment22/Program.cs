﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assignment22
{



    class Program
    {
        static void Main(string[] args)  {

            TextAnalyzer text1 = new TextAnalyzer("");

            SortedList<char, int> results = text1.AnalyzeText();           


            Console.WriteLine("The contnet of the sorted list: ");
            foreach (char ch in results.Keys)
            Console.WriteLine(ch + " --> " + results[ch]);
             
            Console.ReadLine();

        }  
       
    }

}

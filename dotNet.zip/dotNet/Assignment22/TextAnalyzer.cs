﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assignment22
{
    class TextAnalyzer
    {

        string text;


        public TextAnalyzer(string text)
        {
            this.text = text;
        }

        private void GenerateLetters()
        {

            int Lenght = 50;
            int LOWER= 97;
            int UPPER = 122;
            Random random = new Random();            
          
            StringBuilder result = new StringBuilder(Lenght);
            for (int i = 0; i < Lenght; i++)
            {
                result.Append((char)random.Next(LOWER, UPPER));
            }
            this.text =  result.ToString();

            Console.WriteLine(text);
        }


        public SortedList<char, int> AnalyzeText()
        {

            GenerateLetters();

            SortedList<char, int> charList = new SortedList<char, int>();

            foreach (char ch in this.text)
            {
                if (!charList.ContainsKey(ch))
                    charList[ch] = 1;
                else
                    charList[ch]++; 
            }

            return charList;

            
           

        }
       
        public override string ToString()
        {
            return text;

        }       

       
        
    }
}

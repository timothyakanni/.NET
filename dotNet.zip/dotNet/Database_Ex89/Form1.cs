﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Database_Ex89
{
    public partial class Form1 : Form
    {

        OleDbConnection oleDbConnection;

        OleDbCommand oleDbCommand;

        OleDbDataAdapter oleDbDataAdapter;

        DataSet dataSet;

        OleDbCommand insertCommand, updateCommand;
        DataRow newDataRow, updateDataRow;

        string connectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=U:\Northwind.mdb;Persist Security Info=False";

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'northwindDataSet.Employees' table. You can move, or remove it, as needed.
            this.employeesTableAdapter.Fill(this.northwindDataSet.Employees);

            oleDbConnection = new OleDbConnection(connectionString);

        }

        private void insertButton_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrEmpty(firstNameTextBox.Text) || string.IsNullOrEmpty(lastNameTextBox.Text) ||

            string.IsNullOrEmpty(idTextBox.Text))
            {

                MessageBox.Show("Please give valid values!");

                return;

            }

            

            //Here we create a command objecd for inserting new rows

            insertCommand = oleDbConnection.CreateCommand();

            insertCommand.CommandText = "insert into Employees ( EmployeeID, LastName, FirstName) values(@employeeID, @lastName, @firstName)";

            insertCommand.Parameters.Add("@employeeID", OleDbType.Numeric, 5, "EmployeeID");

            insertCommand.Parameters.Add("@lastName", OleDbType.LongVarChar, 20, "LastName");

            insertCommand.Parameters.Add("@firstName", OleDbType.LongVarChar, 10, "FirstName");

            oleDbDataAdapter = new OleDbDataAdapter();

            oleDbDataAdapter.InsertCommand = insertCommand;

            newDataRow = northwindDataSet.Employees.NewRow();            

            newDataRow["EmployeeID"] = idTextBox.Text;

            newDataRow["FirstName"] = firstNameTextBox.Text;

            newDataRow["LastName"] = lastNameTextBox.Text;

            northwindDataSet.Employees.Rows.Add(newDataRow);

            oleDbConnection.Open();

            int numOfRows = oleDbDataAdapter.Update(northwindDataSet.Employees);

            MessageBox.Show(numOfRows + " row was updated");

            oleDbConnection.Close();

            //getDataButton_Click(sender, e);


        }

        private void employeesBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.employeesBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.northwindDataSet);

        }

        private void updateButton_Click(object sender, EventArgs e)
        {
            //Here we make sure that text boxes are not empty

            if (string.IsNullOrEmpty(firstNameTextBox.Text) || string.IsNullOrEmpty(lastNameTextBox.Text) || 
                string.IsNullOrEmpty(idTextBox.Text))
            {

                MessageBox.Show("Please give valid values!");

                return;

            }

            //Here we create a command objec for updating rows

            updateCommand = oleDbConnection.CreateCommand();

            updateCommand.CommandText = "update Employees  set   LastName=@lastname, FirstName=@fisrtName where EmployeeID=@employeeID";



            //Here we define the parameters. Pay attention that the parameters must be defined in the order of usage in the command.

            updateCommand.Parameters.Add("@lastName", OleDbType.LongVarChar, 20, "LastName");

            updateCommand.Parameters.Add("@fisrtName", OleDbType.LongVarChar, 10, "FirstName");

            updateCommand.Parameters.Add("@employeeID", OleDbType.Numeric, 5, "EmployeeID");

            //Here we define the column values of a row on the Employee table 

            object[] employeeData = new object[] { int.Parse(idTextBox.Text), lastNameTextBox.Text, firstNameTextBox.Text };

            //Here we load the table row with given values 

            DataRow updateDataRow = northwindDataSet.Employees.LoadDataRow(employeeData, true);



            //Here we update column values of the row   

            updateDataRow["FirstName"] = firstNameTextBox.Text;

            updateDataRow["LastName"] = lastNameTextBox.Text;

            oleDbDataAdapter = new OleDbDataAdapter();

            oleDbDataAdapter.UpdateCommand = updateCommand;

            int numOfRows = oleDbDataAdapter.Update(northwindDataSet.Employees);

            MessageBox.Show(numOfRows + " row was updated");

            oleDbConnection.Close();

            Form1_Load(sender, e);


        }
    }
}
